$ docker image build -t edmelkoyev/nwp-basic-ui-app:latest .
$ docker image ls

$ docker run -p 8080:8080 -d edmelkoyev/nwp-basic-ui-app:latest

$ docker ps

$ docker exec -it [ContainerID] bash
docker exec -it ab5fa5da1da9 bash


$ docker stop -it [ContainerID]