- docker-compose.yml
- validate
  $ docker-compose config
- start:
  $ docker-compose up
  $ docker-compose up -d
  $ docker-compose up --build
- stop:
  $ docker-compose down


check version:
  $ docker-compose version
  $ docker-compose -v
  docker-compose version 1.24.1, build 4667896b


From: N. Tyukavkin
-------------------
http://was-ggr.aws.wiley.com/#/capabilities/

curl -X POST 'http://ggr-ui:8888/wd/hub/session' -d '{ 
            "desiredCapabilities":{
                "browserName":"chrome", 
                "version": "79.0", 
                "platform":"ANY",
                "enableVNC": true,
                "name": "this.test.is.launched.by.curl",
                "sessionTimeout": "120s"
            }
        }'

curl -X POST 'http://localhost:4444/wd/hub/session' -d '{ "desiredCapabilities":{"browserName":"chrome", "version": "79.0", "platform":"ANY", "enableVNC": true, "name": "this.test.is.launched.by.curl", "sessionTimeout": "120s"}}'





