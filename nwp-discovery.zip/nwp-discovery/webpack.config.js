const mode = process.env.NODE_ENV || 'development'
const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const groupsOptions = {chunks: "all", minSize:0, minChunks: 1, reuseExistingChunk: true, enforce: true};
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const bodyParser = require('body-parser')
const wasConfig = require('./fixtures/was-config')
const ltiLaunchContext = require('./fixtures/ltiLaunchContext')
const wileyQuestionSet = require('./fixtures/wileyQuestionSet')
const userQuestionSet = require('./fixtures/userQuestionSet')

const config = {
    mode: mode,
        devtool: mode === 'development' ? 'source-map': false,
    output: {
        filename: 'app/[name].[chunkhash].js'
    },
    module: {
        rules: [{
            test: /\.(js|jsx)$/,
            exclude: /node_modules/,
            use: {
                loader: 'babel-loader'
            }
        }]
    },
    resolve: {
        modules: [
            './src/app',
            'node_modules'
        ],
        alias: {
            '@app': path.resolve(__dirname, 'src/app')
        },
        extensions: ['*', '.js', '.jsx', '.json']
    },
    optimization: {
        splitChunks: {
            chunks: 'all',
            name: true,
            cacheGroups:{
                vendors: {test:/node_modules/, name: 'vendors', ...groupsOptions},
            }
        }
    },
    entry: {
        app: ['./src/app/index.js']
    },
    devServer: {
        openPage: '?launchId=dev00001',
        historyApiFallback: true,
        before: function(app) {
            app.use(bodyParser.json())
            app.use(bodyParser.urlencoded({ extended: true }))

            app.use((req, res, next) => {
                res.setHeader('Cache-Control', 'no-cache')
                res.setHeader('Access-Control-Allow-Origin', '*')

                next()
            })

            app.get('/was/ui/v2/config/was-config.json', (req, res) => {
                res.setHeader('content-type', 'application/json;charset=UTF-8')
                res.send(wasConfig)
            })

            app.get('/api/v1/launches/dev00001', (req, res) => {
                res.setHeader('content-type', 'application/json;charset=UTF-8')
                res.send(ltiLaunchContext)
            })

            app.get('/api/v1/master/assessments', (req, res) => {
                res.setHeader('content-type', 'application/json;charset=UTF-8')
                res.send(userQuestionSet)
            })

            app.delete('/api/v1/master/assessments/:assessmentId', (req, res) => {
                if(req.params.assessmentId) {
                    res.setHeader('content-type', 'application/json; charset=UTF-8')
                    res.send({})
                }
                else {
                    throw new Error('error')
                }
            })
        }
    },
    plugins: [ new CleanWebpackPlugin() ],
    performance: {
        maxEntrypointSize: 1024000,
        maxAssetSize: 1024000
    }
}

module.exports = () => {
    return {
        ...config,
        plugins: [
            ...config.plugins,
            new HtmlWebpackPlugin({
                template: 'tools/public/index.ejs',
                filename: 'index.html',
                inject: false,
                minify: {
                    collapseWhitespace: true
                },
                links: [
                    {
                        href: 'https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i&display=swap',
                        rel: 'stylesheet'
                    }
                ]
            })
        ]
    }
}