- docker-compose.yml
- validate
  $ docker-compose config
- start:
  $ docker-compose up
  $ docker-compose up -d
  $ docker-compose up --build
  $ docker-compose up --build --remove-orphans
  $ docker-compose up --build --exit-code-from nwp-app
  $ docker-compose up --build --remove-orphans --exit-code-from nwp-app
  $ docker-compose up --exit-code-from nwp-app
- stop:
  $ docker-compose down


check version:
  $ docker-compose version
  $ docker-compose -v
  docker-compose version 1.24.1, build 4667896b

------
docker exec -it aee4f6397be2 bash

