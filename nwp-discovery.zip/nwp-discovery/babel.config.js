module.exports = api => {
  const isTest = api.env('test')

  const config = {
    "presets": [
      "@babel/env",
      "@babel/react"
    ],
    "plugins": [
      "@babel/plugin-transform-runtime",
      "@babel/plugin-proposal-function-bind",
      "@babel/plugin-proposal-export-default-from",
      "@babel/plugin-proposal-logical-assignment-operators",
      ["@babel/plugin-proposal-optional-chaining", {"loose": false}],
      ["@babel/plugin-proposal-pipeline-operator", {"proposal": "minimal"}],
      ["@babel/plugin-proposal-nullish-coalescing-operator", {"loose": false}],
      "@babel/plugin-proposal-do-expressions",
      ["@babel/plugin-proposal-decorators", {"legacy": true}],
      "@babel/plugin-proposal-function-sent",
      "@babel/plugin-proposal-export-namespace-from",
      "@babel/plugin-proposal-numeric-separator",
      "@babel/plugin-proposal-throw-expressions",
      "@babel/plugin-syntax-dynamic-import",
      "@babel/plugin-syntax-import-meta",
      ["@babel/plugin-proposal-class-properties", {"loose": false}],
      "@babel/plugin-proposal-json-strings",
      "@babel/plugin-transform-modules-commonjs"
    ]
  }

  if (!isTest) {
    config.plugins.push([
      "babel-plugin-transform-imports",
      {
        "@nwp/ui-components/components/material/core": {
          "transform": "@material-ui/core/${member}",
          "preventFullImport": true
        },
        "@nwp/ui-components/components/material/icons": {
          "transform": "@material-ui/icons/${member}",
          "preventFullImport": true
        }
      }
    ])
  }

  return config
}