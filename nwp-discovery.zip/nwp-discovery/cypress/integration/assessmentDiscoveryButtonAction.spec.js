// / <reference types="Cypress" />
/*global cy */
/*eslint no-magic-numbers: ["error", { "ignore": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 200] }]*/
import locators from '../support/locators/discoveryTopPanelHeader'
describe('LMS-10277,LMS-10513,LMS-10281,LMS-10276 no Question set screen and  Use set button action in assessment discovery page', function () {
    it('Verify Use set button action in My Question set ', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_USESETASIS_BUTTON).should('not.be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_TIMEDASSIGNMENT_BUTTON)
                .title('This question set has a time limit. Time limits and time accommodations must be updated before use.')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_USESETASIS_BUTTON).should('not.be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_TIMEDASSIGNMENT_BUTTON)
                .title('This question set has a time limit. Time limits and time accommodations must be updated before use.')
        })
    })

    it('Verify Use set button action in Wiley Question set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentQuestionsJson) {
            cy.openDiscoveryLaunchScreen(AssessmentQuestionsJson)
            cy.wileyQuestionsSetTab()
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    // eslint-disable-next-line no-magic-numbers
                    expect($element.get(1).click())
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_USESETASIS_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).should('be.visible')
        })
    })

    it('Verify action of new question set button ', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            const expectedData = {
                url: 'http://localhost:8080/was/ui/v2/assessment-builder/index.html?launchId=dev00001'
            }
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_NEW_QUESTION_SETBUTTON)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.window().then((win) => {
                cy.stub(win, 'open', url => {
                    win.location.href = expectedData.url
                }).as('newTab')
                cy.stub(win, 'close')
            })

        })
    })

    it('Verify the no questions set screen on assessment discovery', function () {
        cy.fixture('wileyQuestionSet.json').then(function (AssessmentDiscoveryJson) {
            cy.server()
            cy.route({
                method: 'GET',
                url: '**/master/assessments**',
                status: 200,
                response: 'fixture:wileyQuestionSet.json'
            })
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_NOQUESTIONSET_IMAGE).should('be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_NEW_QUESTION_SETBUTTON)
                .should('have.text', 'NEW QUESTION SET')
            cy.get(locators.ASSESSMENT_DISCOVERY_NOQUESTIONSET_IMFORMATION_MESSAGE)
                .should('have.text', "You haven't added any Question Sets yet")
            cy.get(locators.ASSESSMENT_DISCOVERY_NEW_QUESTION_SETBUTTON)
                .should(($element) => {
                    expect($element.get(0).click())
                })
        })
    })
})