// / <reference types="Cypress" />
/*global cy */
/*eslint no-magic-numbers: ["error", { "ignore": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 200] }]*/
import locators from '../support/locators/discoveryTopPanelHeader'
describe('LMS-10275, LMS-10278 search acion of My Question set and Wiley Question set assessment discovery page', function () {
    it('LMS-10283 Dublicate and edit close and cancel function for My Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTAINER).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTINUE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're editing this question set in another tab")
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_TITLE).should('be.visible').should('have.text', 'Close question set tab')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_DESCRIPTION).should('be.visible').should('have.text', 'Changes you made to the question set will be discarded. Are you sure you want to close the tab?')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_CLOSE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're editing this question set in another tab")
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_HEADER).should('be.visible')
        })
    })

    it('LMS-10283 Dublicate and edit close and cancel function for Wiley Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.wileyQuestionsSetTab()
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTAINER).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTINUE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're editing this question set in another tab")
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_TITLE).should('be.visible').should('have.text', 'Close question set tab')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_DESCRIPTION).should('be.visible').should('have.text', 'Changes you made to the question set will be discarded. Are you sure you want to close the tab?')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_CLOSE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're editing this question set in another tab")
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_HEADER).should('be.visible')
        })
    })

    it('LMS-10283 Dublicate and edit continue function for My Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.wileyQuestionsSetTab()
            const expectedData = {
                url: 'http://localhost:8080/was/ui/v2/assessment-builder/index.html?launchId=dev00001'
            }
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTINUE_BUTTON).should('be.visible').click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're editing this question set in another tab")
            cy.window().then((win) => {
                cy.stub(win, 'open', url => {
                    win.location.href = expectedData.url
                }).as('newTab')
                cy.stub(win, 'close')
            })
        })
    })

    it('LMS-10283 Dublicate and edit continue function for Wiley Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            const expectedData = {
                url: 'http://localhost:8080/was/ui/v2/assessment-builder/index.html?launchId=dev00001'
            }
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTINUE_BUTTON).should('be.visible').click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're editing this question set in another tab")
            cy.window().then((win) => {
                cy.stub(win, 'open', url => {
                    win.location.href = expectedData.url
                }).as('newTab')
                cy.stub(win, 'close')
            })
        })
    })

    it('LMS-10283 New Question Set close and cancel function for My Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_NEW_QUESTION_SETBUTTON)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTAINER).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTINUE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're creating a question set in another tab")
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_TITLE).should('be.visible').should('have.text', 'Close question set tab')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_DESCRIPTION).should('be.visible').should('have.text', 'The question set will be discarded. Are you sure you want to close the tab?')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_CLOSE_BUTTON).should('be.visible')
            cy.get(locators.ASSESSMENT_BUILDER_CANCEL_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're creating a question set in another tab")
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_BUILDER_CLOSE_BUTTON).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_HEADER).should('be.visible')
        })
    })

    it('LMS-10283 New Question set continue function for My Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            const expectedData = {
                url: 'http://localhost:8080/was/ui/v2/assessment-builder/index.html?launchId=dev00001'
            }
            cy.get(locators.ASSESSMENT_DISCOVERY_NEW_QUESTION_SETBUTTON)
                .should(($element) => {
                    expect($element.get(0).click())
                })
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_CONTINUE_BUTTON).should('be.visible').click()
            cy.get(locators.ASSESSMENT_BUILDER_PROGRESS_MESSAGE).should('have.text', "You're creating a question set in another tab")
            cy.window().then((win) => {
                cy.stub(win, 'open', url => {
                    win.location.href = expectedData.url
                }).as('newTab')
                cy.stub(win, 'close')
            })
        })
    })
})