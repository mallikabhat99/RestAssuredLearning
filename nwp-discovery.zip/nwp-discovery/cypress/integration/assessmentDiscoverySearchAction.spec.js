// / <reference types="Cypress" />
/*global cy */
/*eslint no-magic-numbers: ["error", { "ignore": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 200] }]*/
import locators from '../support/locators/discoveryTopPanelHeader'
describe('LMS-10275, LMS-10278 search acion of My Question set and Wiley Question set assessment discovery page', function () {
    it('verify for My Question set No question set matches your search screen on click cancel verify the question sets', function () {
        cy.fixture('cytests/wileyQuestionSetCypress.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SEARCH_BAR).type('Something')
            cy.get(locators.ASSESSMENT_DISCOVERY_NO_QUESTIONSET_MATCHSCREEN).should('be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_NO_QUESTIONSET_MATCHSCREEN).should('have.text', 'No question sets match your search')
            cy.get(locators.ASSESSMENT_DISCOVERY_CLEAR_SEARCH_BUTTON).click()
        })
    })

    it('verify Search question set in my question set', function () {
        cy.fixture('cytests/wileyQuestionSetCypress.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SEARCH_BAR).type('wiley assessment')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_NAME_HEADER)
                .should('have.text', 'Question Set Name')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_NAME_COLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('wiley assessment')
                })
            cy.get(locators.ASSSESSMENT_DISCOVERY_QUESTION_SET_COUNTHEADER)
                .should('have.text', 'Questions')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_COUNTCOLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('9')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_HEADER)
                .should('have.text', 'Policy Profile')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('Homework')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('USE SET')
                })
        })
    })

    it('verify for Wiley Question set No question set matches your search screen on click cancel verify the question sets', function () {
        cy.fixture('cytests/wileyQuestionSetCypress.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.wileyQuestionsSetTab()
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SEARCH_BAR).type('Something')
            cy.get(locators.ASSESSMENT_DISCOVERY_NO_QUESTIONSET_MATCHSCREEN).should('be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_NO_QUESTIONSET_MATCHSCREEN).should('have.text', 'No question sets match your search')
            cy.get(locators.ASSESSMENT_DISCOVERY_CLEAR_SEARCH_BUTTON).click()
        })
    })

    it('verify Search question set in wiley question set', function () {
        cy.fixture('cytests/wileyQuestionSetCypress.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.wileyQuestionsSetTab()
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SEARCH_BAR).type('wiley assessment')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_NAME_HEADER)
                .should('have.text', 'Question Set Name')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_NAME_COLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('wiley assessment')
                })
            cy.get(locators.ASSSESSMENT_DISCOVERY_QUESTION_SET_COUNTHEADER)
                .should('have.text', 'Questions')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_COUNTCOLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('9')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_HEADER)
                .should('have.text', 'Policy Profile')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('Homework')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('USE SET')

                })
        })
    })
})