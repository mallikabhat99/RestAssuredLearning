// / <reference types="Cypress" />
/*global cy */
/*eslint no-magic-numbers: ["error", { "ignore": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 200] }]*/
import discoveryBlock from '../support/locators/discoveryTopPanelHeader'
import testData from '../support/testData'

describe('LMS-11175,LMS-11064 Discovery Tool Icons and Edit Password while reusing secure password question sets', function () {
    const secureTooltip = 'This question set has a password. Duplicate the set to avoid affecting other assignments\' passwords.'
    const timedTooltip = 'This question set has a time limit. Time limits and time accommodations must be updated before use.'
    const timedSecureTooltip = 'This question set has time and password policies. Duplicate the set to avoid affecting other assignments.'
    const timedIconToolTip = 'Time limit set'
    const secureIconToolTip = 'Password required'

    beforeEach('test data preparation', () => {
        cy.server()
        cy.route({
            method: 'GET',
            url: '**/master/assessments**',
            response: 'fixture:cytests/11064UserQuestionSets.json',
            status: 200
        }).as('userQuestionSets')
        cy.visit(testData.DISCOVERY_LAUNCH_URL)
        cy.wait('@userQuestionSets').its('status').should('eq', 200)
    })

    it('Check icons not displayed for Non-timed question set', () => {
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(0).children().find(discoveryBlock.ASSESSMENT_DISCOVERY_TIME_DURATION_ICON).should('not.exist')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(0).children().find(discoveryBlock.ASSESSMENT_DISCOVERY_SECUREPOLICY_APPLICABLE_ICON).should('not.exist')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN).eq(0).click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_USESETASIS_BUTTON).should('be.visible').should('have.attr', 'aria-disabled', 'false')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TIMEDASSIGNMENT_BUTTON).should('not.exist')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).should('be.visible').should('have.attr', 'aria-disabled', 'false')
    })

    it('Check icon and tooltip display for Non-timed Secure question set', () => {
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(1).children().find(discoveryBlock.ASSESSMENT_DISCOVERY_SECUREPOLICY_APPLICABLE_ICON).should('be.visible')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(1).children().find(discoveryBlock.ASSESSMENT_DISCOVERY_SECUREPOLICY_APPLICABLE_ICON).trigger('mouseover')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TOOLTIP_LOCATOR).contains(secureIconToolTip).should('be.visible')
        cy.get('body').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN).eq(1).click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_USESETASIS_BUTTON).should('not.be.visible').should('have.attr', 'aria-disabled', 'true')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TIMEDASSIGNMENT_BUTTON).trigger('mouseover').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TOOLTIP_LOCATOR).contains(secureTooltip).should('be.visible')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).should('be.visible').should('have.attr', 'aria-disabled', 'false')
    })

    it('Check icon and tool tip display for Timed question set', () => {
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(2).children().find(discoveryBlock.ASSESSMENT_DISCOVERY_TIME_DURATION_ICON).should('be.visible')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(2).find(discoveryBlock.ASSESSMENT_DISCOVERY_TIME_DURATION_ICON).trigger('mouseover')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TOOLTIP_LOCATOR).contains(timedIconToolTip).should('be.visible')
        cy.get('body').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN).eq(2).click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_USESETASIS_BUTTON).should('not.be.visible').should('have.attr', 'aria-disabled', 'true')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TIMEDASSIGNMENT_BUTTON).trigger('mouseover').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TOOLTIP_LOCATOR).contains(timedTooltip).should('be.visible')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).should('be.visible').should('have.attr', 'aria-disabled', 'false')
    })

    it('Check icon and tooltip display for Timed Secure question set', () => {
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(3).find(discoveryBlock.ASSESSMENT_DISCOVERY_SECUREPOLICY_APPLICABLE_ICON).should('be.visible')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(3).find(discoveryBlock.ASSESSMENT_DISCOVERY_SECUREPOLICY_APPLICABLE_ICON).trigger('mouseover').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TOOLTIP_LOCATOR).contains(secureIconToolTip).should('be.visible')
        cy.get('body').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(3).find(discoveryBlock.ASSESSMENT_DISCOVERY_TIME_DURATION_ICON).should('be.visible')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN).eq(3).find(discoveryBlock.ASSESSMENT_DISCOVERY_TIME_DURATION_ICON).trigger('mouseover').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TOOLTIP_LOCATOR).contains(timedIconToolTip).should('be.visible')
        cy.get('body').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN).eq(3).click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_USESETASIS_BUTTON).should('not.be.visible').should('have.attr', 'aria-disabled', 'true')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TIMEDASSIGNMENT_BUTTON).trigger('mouseover').click()
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_TOOLTIP_LOCATOR).contains(timedSecureTooltip).should('be.visible')
        cy.get(discoveryBlock.ASSESSMENT_DISCOVERY_MODIFYANDUSESET_BUTTON).should('be.visible').should('have.attr', 'aria-disabled', 'false')
    })

})