// / <reference types="Cypress" />
/*global cy */
/*eslint no-magic-numbers: ["error", { "ignore": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 200] }]*/
import locators from '../support/locators/discoveryTopPanelHeader'
describe('LMS-10272,LMS-10273 and LMS-10274 verify the elements and text in assessment discovery page', function () {

    it('verify the elements and text in my question set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_HEADER)
                .should('have.text', 'Select a question set')
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_HEADER2)
                .should('have.text', 'You can start with an existing question set or create a new one from scratch')
            cy.get(locators.ASSESSMENT_DISCOVERY_NEW_QUESTION_SETBUTTON)
                .should('have.text', 'NEW QUESTION SET')
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_TAB)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('MY QUESTION SETS (2)')
                    expect($element.get(1).innerText).to.eq('WILEY QUESTION SETS (2)')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_NAME_HEADER)
                .should('have.text', 'Question Set Name')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_NAME_COLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('Copy of Accommodated Qset')
                })
            cy.get(locators.ASSSESSMENT_DISCOVERY_QUESTION_SET_COUNTHEADER)
                .should('have.text', 'Questions')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_COUNTCOLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('3')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_HEADER)
                .should('have.text', 'Policy Profile')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('Custom')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('USE SET')
                })
        })
    })

    it('verify the elements and text in wiley questions sets', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentQuestionsJson) {
            cy.openDiscoveryLaunchScreen(AssessmentQuestionsJson)
            cy.wileyQuestionsSetTab()
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_TAB)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('MY QUESTION SETS (2)')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_NAME_HEADER)
                .should('have.text', 'Question Set Name')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_NAME_COLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('Copy of Accommodated Qset')
                })
            cy.get(locators.ASSSESSMENT_DISCOVERY_QUESTION_SET_COUNTHEADER)
                .should('have.text', 'Questions')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_COUNTCOLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('3')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_HEADER)
                .should('have.text', 'Policy Profile')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_POLICY_PROFILE_COLUMN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('Custom')
                })
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTION_SET_DRPDWNBTN)
                .should(($element) => {
                    expect($element.get(0).innerText).to.eq('USE SET')
                })
        })
        cy.myQuestionsSetTab()
        cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_TAB)
            .should(($element) => {
                expect($element.get(0).innerText).to.eq('MY QUESTION SETS (2)')
            })
    })
})