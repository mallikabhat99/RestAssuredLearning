// / <reference types="Cypress" />
/*global cy */
/*eslint no-magic-numbers: ["error", { "ignore": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 200] }]*/
import locators from '../support/locators/discoveryTopPanelHeader'
describe('LMS-10808 Error screen in assessment discovery page', function () {
    it('Verify error screen on assessment discovery', () => {
        cy.server()
        cy.route({
            method: 'GET',
            url: '**/master/assessments**',
            status: 404,
            response: 'fixture:cytests/wileyQuestionSet.json'
        }).as('errorScreen')

        cy.openDiscoveryLaunchScreen()
        cy.get(locators.ASSESSMENT_DISCOVERY_ERROR_IMAGE).should('be.visible')
        cy.get(locators.ASSESSMENT_DISCOVERY_TRY_AGAIN_BUTTON)
            .should('have.text', 'TRY AGAIN')
        cy.get(locators.ASSESSMENT_DISCOVERY_ERROR_MESSAGE)
            .should('have.text', 'There was an error loading question sets')
        cy.get(locators.ASSESSMENT_DISCOVERY_TRY_AGAIN_BUTTON).click()
    })

})