// / <reference types="Cypress" />
/*global cy */
/*eslint no-magic-numbers: ["error", { "ignore": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 200] }]*/
import locators from '../support/locators/discoveryTopPanelHeader'
describe('Delete Question set action of My Question set and Wiley Question set assessment discovery page', function () {
    it('LMS-10280 cancel deletion My Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_ELIPPSIS_ICON)
                .should('be.visible')
                .eq(0)
                .click()
            cy.get(locators.ASSESSMENT_DISCOVERY_DELETE_QUESTION_SET).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_REMOVE_QUESTION_SET_DIALOG_TITLE).should('have.text', 'Delete question set')
            cy.get(locators.ASSESSMENT_DISCOVERY_REMOVE_QUESTION_SET_DIALOG_DESCRIPTION).should('have.text', "You are about to delete this question set. You won't be able to use it in new assignments. Existing assignments will not be impacted.")
            cy.get(locators.ASSESSMENT_DISCOVERY_CANCEL_QUESTIONSET_BUTTON).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_HEADER).should('be.visible')
        })
    })

    it('LMS-10280 delete My Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_ELIPPSIS_ICON)
                .eq(0)
                .click()
            cy.get(locators.ASSESSMENT_DISCOVERY_DELETE_QUESTION_SET).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_REMOVE_QUESTION_SET_DIALOG_TITLE).should('have.text', 'Delete question set')
            cy.get(locators.ASSESSMENT_DISCOVERY_REMOVE_QUESTION_SET_DIALOG_DESCRIPTION)
                .should('have.text', "You are about to delete this question set. You won't be able to use it in new assignments. Existing assignments will not be impacted.")
            cy.get(locators.ASSESSMENT_DISCOVERY_REMOVE_QUESTIONSET_BUTTON).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_TOP_PANEL_HEADER).should('be.visible')
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTIONSET_DELETE_SNACKBAR_MESSAGE).should('be.visible').should('have.text', 'Question set deleted')
        })
    })

    it('LMS-10280 delete question set disbaled for wiley question set ', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.wileyQuestionsSetTab()
            cy.get(locators.ASSESSMENT_DISCOVERY_ELIPPSIS_ICON).should('not.be.visible')
        })
    })

    it('LMS-10280 failed to delete My Question Set', function () {
        cy.fixture('cytests/discoverymyquestionset.json').then(function (AssessmentDiscoveryJson) {
            cy.server()
            cy.route({
                method: 'DELETE',
                url: '/api/v1/master/assessments/00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                response: 'fixture:cytests/discoverymyquestionset.json',
                status: 400
            })
            cy.openDiscoveryLaunchScreen(AssessmentDiscoveryJson)
            cy.get(locators.ASSESSMENT_DISCOVERY_ELIPPSIS_ICON)
                .eq(0)
                .click()
            cy.get(locators.ASSESSMENT_DISCOVERY_DELETE_QUESTION_SET).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_REMOVE_QUESTIONSET_BUTTON).click()
            cy.get(locators.ASSESSMENT_DISCOVERY_QUESTIONSET_DELETE_SNACKBAR_MESSAGE).should('be.visible').should('have.text', 'Failed to delete question set')

        })
    })
})