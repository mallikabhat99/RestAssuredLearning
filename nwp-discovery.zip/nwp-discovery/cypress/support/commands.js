/* global cy Cypress */

// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add("login", (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add("drag", { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add("dismiss", { prevSubject: 'optional'}, (subject, options) => { ... })
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite("visit", (originalFn, url, options) => { ... })

import testData from './testData'
import overviewElements from '../support/locators/discoveryTopPanelHeader'

Cypress.Commands.add('openDiscoveryLaunchScreen', (AssessmentDiscovery) => {
    cy.server()
    cy.visit(testData.LAUNCH_SCREEN_APP_URL.concat(AssessmentDiscovery, '#/applaunch'))
    cy.route('GET', '**/master/assessments**', AssessmentDiscovery)
    cy.route('GET', 'master/assessments?product=*&author=Wiley', 'fixture:cytests/wileyQuestionSetCypress.json')
    cy.get('svg[class^="MuiCircularProgress"]', { timeout: 1000 }).should('not.be.visible')

})
Cypress.Commands.add('wileyQuestionsSetTab', () => {
    cy.get(overviewElements.ASSESSMENT_DISCOVERY_TOP_PANEL_TAB).eq(1).click()
})
Cypress.Commands.add('myQuestionsSetTab', () => {
    cy.get(overviewElements.ASSESSMENT_DISCOVERY_TOP_PANEL_TAB).eq(0).click()
})