export default {
    APP_URL: 'localhost:8080',
    LAUNCH_SCREEN_APP_URL: 'http://localhost:8080/?launchId=dev00001&assessmentDiscovery=',
    DISCOVERY_LAUNCH_URL: 'http://localhost:8080/?launchId=dev00001'
}