/*eslint "no-magic-numbers": ["error", {"ignore": [2, 15, 66, 200]}],*/
import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import { ConnectedRouter } from 'connected-react-router'
import { themes, CssBaseline } from '@nwp/ui-components'

import _ from 'underscore'

import App from './App'
import store, { history } from './storage'

const root = document.getElementById('root')

ReactDOM.render(
    <themes.DefaultThemeProvider>
        <CssBaseline />
        <Provider store={store}>
            <ConnectedRouter history={history}>
                <App />
            </ConnectedRouter>
        </Provider>
    </themes.DefaultThemeProvider>,
    document.getElementById('root')
)

if (parent && parent !== self) {
    (() => {
        let height = 0
        const ltiFrameResize = _.debounce(() =>
            parent.postMessage(JSON.stringify({
                subject: 'lti.frameResize',
                height: height + 15
            }), '*')
        , 200)

        setInterval(() => {
            const outerHeight = root.offsetHeight
            if (Math.abs(height - outerHeight) > 2) {
                height = outerHeight + 2
                ltiFrameResize()
            }
        }, 66)
    })()
}
