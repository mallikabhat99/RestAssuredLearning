/* globals jest, expect, describe, it, beforeEach, afterEach */

import { LocalStorageActions, SessionStorageActions } from '../actions'
import sessionAndLocalStorageMiddleware from './sessionAndLocalStorageMiddleware'

describe('sessionAndLocalStorageMiddleware', () => {
    let next
    let middleware

    describe('local storage actions', () => {

        beforeEach(() => {
            next = jest.fn()
            middleware = sessionAndLocalStorageMiddleware()(next)
            localStorage.setItem('test', JSON.stringify({ initial: 'initial' }))
        })

        afterEach(() => {
            localStorage.removeItem('test')
        })

        it('should update local storage with save LocalStorageActions action', () => {
            middleware(LocalStorageActions.save('test', { test: 'test' }))

            expect(JSON.parse(localStorage.getItem('test'))).toEqual({ test: 'test' })
        })

        it('should update local storage with update LocalStorageActions action', () => {
            middleware(LocalStorageActions.update('test', { test: 'test' }))

            expect(JSON.parse(localStorage.getItem('test'))).toEqual({ initial: 'initial', test: 'test' })
        })

        describe('after remove LocalStorageActions action', () => {
            beforeEach(() => {
                middleware(LocalStorageActions.remove('test', { test: 'test' }))
            })

            it('should have empty local storage', () => {
                expect(localStorage.getItem('test')).toBeFalsy()
            })

            it('should update local storage with update LocalStorageActions action', () => {
                middleware(LocalStorageActions.update('test', { test: 'test' }))

                expect(JSON.parse(localStorage.getItem('test'))).toEqual({ test: 'test' })
            })
        })
    })

    describe('session storage actions', () => {

        beforeEach(() => {
            next = jest.fn()
            middleware = sessionAndLocalStorageMiddleware()(next)
            sessionStorage.setItem('test', JSON.stringify({ initial: 'initial' }))
        })

        afterEach(() => {
            sessionStorage.removeItem('test')
        })

        it('should update local storage with save SessionStorageActions action', () => {
            middleware(SessionStorageActions.save('test', { test: 'test' }))

            expect(JSON.parse(sessionStorage.getItem('test'))).toEqual({ test: 'test' })
        })

        it('should update local storage with update SessionStorageActions action', () => {
            middleware(SessionStorageActions.update('test', { test: 'test' }))

            expect(JSON.parse(sessionStorage.getItem('test'))).toEqual({ initial: 'initial', test: 'test' })
        })

        describe('after remove SessionStorageActions action', () => {
            beforeEach(() => {
                middleware(SessionStorageActions.remove('test', { test: 'test' }))
            })

            it('should have empty local storage', () => {
                expect(sessionStorage.getItem('test')).toBeFalsy()
            })

            it('should update local storage with update SessionStorageActions action', () => {
                middleware(SessionStorageActions.update('test', { test: 'test' }))

                expect(JSON.parse(sessionStorage.getItem('test'))).toEqual({ test: 'test' })
            })
        })
    })
})
