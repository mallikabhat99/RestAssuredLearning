import { LocalStorageActions, SessionStorageActions } from '../actions'

const sessionAndLocalStorageMiddleware = () => next => action => {
    if (action.type === LocalStorageActions.save.toString()) {
        localStorage.setItem(action.payload.key, JSON.stringify(action.payload.value))
    }
    if (action.type === LocalStorageActions.update.toString()) {
        const currentObject = localStorage.getItem(action.payload.key)

        localStorage.setItem(
            action.payload.key,
            JSON.stringify(
                currentObject
                    ? { ...JSON.parse(currentObject), ...action.payload.value }
                    : action.payload.value
            )
        )
    }
    if (action.type === LocalStorageActions.remove.toString()) {
        localStorage.removeItem(action.payload)
    }
    if (action.type === SessionStorageActions.save.toString()) {
        sessionStorage.setItem(action.payload.key, JSON.stringify(action.payload.value))
    }
    if (action.type === SessionStorageActions.update.toString()) {
        const currentObject = sessionStorage.getItem(action.payload.key)

        sessionStorage.setItem(
            action.payload.key,
            JSON.stringify(
                currentObject
                    ? { ...JSON.parse(currentObject), ...action.payload.value }
                    : action.payload.value
            )
        )
    }
    if (action.type === SessionStorageActions.remove.toString()) {
        sessionStorage.removeItem(action.payload)
    }
    return next(action)
}

export default sessionAndLocalStorageMiddleware
