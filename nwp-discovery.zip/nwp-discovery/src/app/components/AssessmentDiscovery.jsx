import React, {useEffect} from 'react'
import PropTypes from 'prop-types'
import { Box, Typography, PageAppBar, Grid, Tabs, Tab, makeStyles, Skeleton } from '@nwp/ui-components'

import { appPartsArray } from '../entities/AppParts'
import { AppParts, RequestStatus } from '../entities'

const useStyles = makeStyles(theme => ({
    disableBoxShadow: {
        boxShadow: 'none'
    },
    questionSetTabWidth: {
        [theme.breakpoints.only('xs')]: {
            maxWidth: '50%'
        }
    }
}))

const AssessmentDiscovery = ({
    getQuestionSets,
    match: { params: { tab } },
    onPush,
    userQuestionSets,
    wileyQuestionSets,
    onTabChange,
    userQuestionSetsRequestStatus,
    wileyQuestionSetsRequestStatus
}) => {

    const classes = useStyles()
    useEffect(() => {
        getQuestionSets(AppParts.WILEY_QUESTION_SET.name)
        getQuestionSets(AppParts.MY_QUESTION_SET.name)
    }, [])

    const handleOnChange = (event, selectedTab) => {
        onPush(`${selectedTab}`)
        onTabChange(selectedTab)
    }

    return (
        <PageAppBar position="static" className={classes.disableBoxShadow} color="inherit" data-testid="assessmentDiscoveryTopPanel">
            <Box px={{xs: 4, sm: 10, md: 0}}>
                <Grid container>
                    <Grid item xs={12} data-testid="assessment-discovery-top-panel-text">
                        <Box py={10}>
                            <Typography variant="h2" data-testid="assessmentDiscoveryTopPanelHeader1">Select a question set</Typography>
                            <Box pt={3}>
                                <Typography variant="body1" data-testid="assessmentDiscoveryTopPanelHeader2">You can start with an existing question set or create a new one from scratch</Typography>
                            </Box>
                        </Box>
                    </Grid>
                    <Grid item xs={12}>
                        <Box>
                            <Tabs
                                indicatorColor="primary"
                                textColor="primary"
                                value={tab}
                                onChange={handleOnChange}
                                data-testid="assessmentDiscoveryTopPanelTabs"
                            >
                                {appPartsArray.map((item) => {
                                    return (
                                        <Tab
                                            data-testid="assessmentDiscoveryTopPanelTab"
                                            key={item.name}
                                            label={item.name === AppParts.MY_QUESTION_SET.name
                                                ? ((userQuestionSetsRequestStatus === RequestStatus.INITIAL || userQuestionSetsRequestStatus === RequestStatus.PROGRESS) ? <Box display="inherit" alignItems="center">{item.value}<Box pl={1}><Skeleton variant="text" animation="wave" height={20} width={20} /></Box></Box> : `${item.value} (${userQuestionSets.length})`)
                                                : ((wileyQuestionSetsRequestStatus === RequestStatus.INITIAL || wileyQuestionSetsRequestStatus === RequestStatus.PROGRESS) ? <Box display="inherit" alignItems="center">{item.value}<Box pl={1}><Skeleton variant="text" animation="wave" height={20} width={20} /></Box></Box> : `${item.value} (${wileyQuestionSets.length})`)}
                                            value={item.name}
                                            className={classes.questionSetTabWidth}
                                        />
                                    )
                                })}
                            </Tabs>
                        </Box>
                    </Grid>
                </Grid>
            </Box>
        </PageAppBar>
    )
}

AssessmentDiscovery.propTypes = {
    getQuestionSets: PropTypes.func.isRequired,
    match: PropTypes.object.isRequired,
    onPush: PropTypes.func.isRequired,
    userQuestionSets: PropTypes.array.isRequired,
    wileyQuestionSets: PropTypes.array.isRequired,
    onTabChange: PropTypes.func.isRequired,
    userQuestionSetsRequestStatus: PropTypes.string.isRequired,
    wileyQuestionSetsRequestStatus: PropTypes.string.isRequired
}

export default AssessmentDiscovery