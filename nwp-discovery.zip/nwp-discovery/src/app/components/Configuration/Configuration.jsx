import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import { Redirect } from 'react-router-dom'

import { RequestStatus } from '../../entities'
import {
    Box, CircularProgress, ContentContainer, FailedToLoad, Typography
} from '@nwp/ui-components'

class Configuration extends PureComponent {

    constructor (props) {
        super(props)

        this.handleRetryConfiguration = this.handleRetryConfiguration.bind(this)
        this.handleRetryGetLaunchContext = this.handleRetryGetLaunchContext.bind(this)
    }

    handleRetryConfiguration () {
        const { getConfigurationFile } = this.props
        getConfigurationFile()
    }

    handleRetryGetLaunchContext () {
        const { getLaunchContext } = this.props
        getLaunchContext()
    }

    componentDidMount () {
        const {
            launchIdStatus,
            setEntryPoint,
            setLaunchIdStatus
        } = this.props

        if (launchIdStatus === RequestStatus.INITIAL) {
            const queryString = window.location.search
            const urlParams = new URLSearchParams(queryString)

            if (urlParams.has('launchId')) {
                setEntryPoint('discovery', urlParams.get('launchId'))
            } else {
                setLaunchIdStatus(RequestStatus.ERROR)
            }
        }
    }

    componentDidUpdate () {
        const {
            launchIdStatus,
            configurationRequestStatus,
            launchContextRequestStatus,
            getConfigurationFile,
            getLaunchContext
        } = this.props

        if (launchIdStatus === RequestStatus.OK && configurationRequestStatus === RequestStatus.INITIAL) {
            getConfigurationFile()
        }

        if (configurationRequestStatus === RequestStatus.OK && launchContextRequestStatus === RequestStatus.INITIAL) {
            getLaunchContext()
        }
    }

    render () {
        const { configurationRequestStatus, launchContextRequestStatus, entryPoint, launchIdStatus } = this.props
        const errorMsg = 'There was an error opening your assignment discovery'

        return (
            <Box flexGrow={1} style={{ overflowY: 'auto' }} data-testid="configurationPage">
                <ContentContainer variant="main">
                    <Box pt={20} pb={1} display="flex" flexDirection="column" justifyContent="center" alignItems="center">

                        {launchIdStatus === RequestStatus.INITIAL &&
                        <Typography data-testid="configStatus" component="span" variant="body1">
                            Capture LaunchID
                        </Typography>}

                        {launchIdStatus === RequestStatus.ERROR &&
                        <FailedToLoad width={235}>
                            <Typography color="textPrimary" variant="h6">
                                {errorMsg}
                            </Typography>
                        </FailedToLoad>}

                        {(
                            launchIdStatus === RequestStatus.OK &&
                   configurationRequestStatus === RequestStatus.INITIAL &&
                   launchContextRequestStatus === RequestStatus.INITIAL) &&
                       <Typography data-testid="configStatus" component="span" variant="body1">
                           CONFIG: Initial
                       </Typography>}

                        {((configurationRequestStatus === RequestStatus.PROGRESS && launchContextRequestStatus === RequestStatus.INITIAL) ||
                       (configurationRequestStatus === RequestStatus.OK && launchContextRequestStatus === RequestStatus.PROGRESS)) &&
                       <Box data-testid="configStatus" display="flex" flexDirection="column" justifyContent="center" alignItems="center">
                           <CircularProgress size={67} />
                           <Box mt={8} mb={4}>
                               <Typography my={4} color="textPrimary" variant="h3">We’re opening the Assignment Discovery</Typography>
                           </Box>
                           <Typography color="textPrimary" component="span" variant="body1">This should only take a few moments</Typography>
                       </Box>}

                        {configurationRequestStatus === RequestStatus.ERROR &&
                        <FailedToLoad width={235} onTryAgain={this.handleRetryConfiguration}>
                            <Typography color="textPrimary" variant="h6">
                                {errorMsg}
                            </Typography>
                        </FailedToLoad>}

                        {(configurationRequestStatus === RequestStatus.OK && launchContextRequestStatus === RequestStatus.INITIAL) &&
                        <Typography data-testid="configStatus" component="span" variant="body1">
                            CONFIG: is Loaded! LAUNCH: Initial
                        </Typography>}

                        {(configurationRequestStatus === RequestStatus.OK && launchContextRequestStatus === RequestStatus.ERROR) &&
                        <FailedToLoad width={235} onTryAgain={this.handleRetryGetLaunchContext}>
                            <Typography color="textPrimary" variant="h6">
                                {errorMsg}
                            </Typography>
                        </FailedToLoad>}

                        {launchContextRequestStatus === RequestStatus.OK &&
                        <Redirect to={`/${entryPoint}`} />}
                    </Box>
                </ContentContainer>
            </Box>
        )
    }
}
Configuration.propTypes = {
    configurationRequestStatus: PropTypes.string.isRequired,
    launchIdStatus: PropTypes.string.isRequired,
    launchContextRequestStatus: PropTypes.string.isRequired,
    entryPoint: PropTypes.string.isRequired,
    getConfigurationFile: PropTypes.func.isRequired,
    getLaunchContext: PropTypes.func.isRequired,
    setEntryPoint: PropTypes.func.isRequired,
    setLaunchIdStatus: PropTypes.func.isRequired
}

export default Configuration