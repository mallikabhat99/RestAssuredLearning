/* global expect, describe, it, beforeEach */

import React from 'react'
import { mount } from 'enzyme'
import { MemoryRouter, Redirect } from 'react-router-dom'
import Configuration from './Configuration'
import { RequestStatus } from '../../entities'

describe('Configuration component', () => {
    let configurationProps
    let configuration
    let configStatus

    it('should be defined', () => {
        expect(Configuration).toBeDefined()
    })

    describe('Rendering of Config loading', () => {

        beforeEach(() => {
            configurationProps = {
                assessment: {
                    title: '',
                    items: []
                },
                launchIdStatus: RequestStatus.INITIAL,
                configurationRequestStatus: RequestStatus.INITIAL,
                launchContextRequestStatus: RequestStatus.INITIAL,
                setLaunchIdStatus: jest.fn(),
                getConfigurationFile: jest.fn(),
                getLaunchContext: jest.fn(),
                setEntryPoint: jest.fn(),
                entryPoint: '',
                match: {
                    params: { entryPoint: '/details' }
                }
            }
        })

        it('should render Capture LaunchID INITIAL status', () => {
            configuration = mount(<Configuration {...configurationProps} />)
            configStatus = configuration.find('span[data-testid="configStatus"]')

            expect(configStatus.exists()).toBeTruthy()
            expect(configStatus.text()).toEqual('Capture LaunchID')
            expect(configurationProps.setLaunchIdStatus).toHaveBeenCalled()
            expect(configurationProps.setEntryPoint).not.toHaveBeenCalled()
            expect(configurationProps.getConfigurationFile).not.toHaveBeenCalled()
        })

        it('should render Capture LaunchID ERROR status', () => {
            configurationProps.launchIdStatus = RequestStatus.ERROR
            configuration = mount(<Configuration {...configurationProps} />)
            configStatus = configuration.find('FailedToLoad')

            expect(configStatus.exists()).toBeTruthy()
            expect(configStatus.find('h6').text()).toEqual('There was an error opening your assignment discovery')
        })

        it('should render get config INITIAL status', () => {
            configuration = mount(<Configuration {...configurationProps} />)
            configuration.setProps({ ...configurationProps, launchIdStatus: RequestStatus.OK })

            configStatus = configuration.find('span[data-testid="configStatus"]')
            expect(configStatus.exists()).toBeTruthy()
            expect(configStatus.text()).toEqual('CONFIG: Initial')
            expect(configurationProps.getConfigurationFile).toHaveBeenCalled()
        })

        it('should render get config PROGRESS status', () => {
            configuration = mount(<Configuration {...configurationProps} />)
            configuration.setProps({ ...configurationProps, launchIdStatus: RequestStatus.OK, configurationRequestStatus: RequestStatus.PROGRESS })
            configStatus = configuration.find('div[data-testid="configStatus"]')

            expect(configStatus.exists()).toBeTruthy()
            expect(configStatus.find('h3').text()).toEqual('We’re opening the Assignment Discovery')
            expect(configStatus.find('span').text()).toEqual('This should only take a few moments')
            expect(configurationProps.getConfigurationFile).not.toHaveBeenCalled()
        })

        it('should render get config ERROR status', () => {
            configuration = mount(<Configuration {...configurationProps} />)
            configuration.setProps({ ...configurationProps, launchIdStatus: RequestStatus.OK, configurationRequestStatus: RequestStatus.ERROR })
            configStatus = configuration.find('FailedToLoad')

            expect(configStatus.exists()).toBeTruthy()
            expect(configStatus.find('h6').text()).toEqual('There was an error opening your assignment discovery')
            expect(configurationProps.setEntryPoint).not.toHaveBeenCalled()
            expect(configurationProps.getConfigurationFile).not.toHaveBeenCalled()

            const button = configuration.find('button')
            button.simulate('click')
            expect(configurationProps.getConfigurationFile).toHaveBeenCalled()
        })

        it('should call getLaunchContext upon successful configurationRequestStatus update ', () => {
            configuration = mount(<Configuration {...configurationProps} />)
            configuration.setProps({ ...configurationProps, launchIdStatus: RequestStatus.OK, configurationRequestStatus: RequestStatus.OK })

            expect(configurationProps.getLaunchContext).toHaveBeenCalled()
        })
    })

    describe('Rendering of Launch Context loading', () => {
        beforeEach(() => {
            configurationProps = {
                assessment: {
                    title: '',
                    items: []
                },
                launchIdStatus: RequestStatus.OK,
                configurationRequestStatus: RequestStatus.OK,
                launchContextRequestStatus: RequestStatus.INITIAL,
                setLaunchIdStatus: jest.fn(),
                getConfigurationFile: jest.fn(),
                getLaunchContext: jest.fn(),
                setEntryPoint: jest.fn(),
                entryPoint: '',
                match: {
                    params: { entryPoint: '/details' }
                }
            }
        })

        it('should render Launch INITIAL status', () => {
            configuration = mount(<Configuration {...configurationProps} />)
            configStatus = configuration.find('span[data-testid="configStatus"]')

            expect(configStatus.exists()).toBeTruthy()
            expect(configStatus.text()).toEqual('CONFIG: is Loaded! LAUNCH: Initial')
        })

        it('should render Launch PROGRESS status', () => {
            configurationProps.launchContextRequestStatus = RequestStatus.PROGRESS
            configuration = mount(<Configuration {...configurationProps} />)
            configStatus = configuration.find('div[data-testid="configStatus"]')

            expect(configStatus.exists()).toBeTruthy()
            expect(configStatus.find('h3').text()).toEqual('We’re opening the Assignment Discovery')
            expect(configStatus.find('span').text()).toEqual('This should only take a few moments')
        })

        it('should render Launch ERROR status', () => {
            configurationProps.launchContextRequestStatus = RequestStatus.ERROR
            configuration = mount(<Configuration {...configurationProps} />)
            configStatus = configuration.find('FailedToLoad')

            expect(configStatus.exists()).toBeTruthy()
            expect(configStatus.find('h6').text()).toEqual('There was an error opening your assignment discovery')
            expect(configurationProps.getConfigurationFile).not.toHaveBeenCalled()

            const button = configuration.find('button')
            button.simulate('click')
            expect(configurationProps.getLaunchContext).toHaveBeenCalled()
        })

        it('should render OK status', () => {
            configurationProps.configurationRequestStatus = RequestStatus.OK
            configurationProps.launchContextRequestStatus = RequestStatus.OK
            configuration = mount(
                <MemoryRouter>
                    <Configuration {...configurationProps} />
                </MemoryRouter>
            )
            configStatus = configuration.find(Redirect)

            expect(configStatus.exists()).toBeTruthy()
            expect(configurationProps.setEntryPoint).not.toHaveBeenCalled()
            expect(configurationProps.getConfigurationFile).not.toHaveBeenCalled()
        })
    })
})