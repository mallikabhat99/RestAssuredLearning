/* globals expect, beforeEach, describe, it */

import React from 'react'
import { mount } from 'enzyme'

import { NotFound } from '.'

describe('NotFound Component', () => {
    let notFoundProps
    let notFound

    it('should be defined', () => {
        expect(NotFound).toBeDefined()
    })

    describe('Rendering', () => {
        beforeEach(() => {
            notFoundProps = {}
            notFound = mount(<NotFound {...notFoundProps} />)
        })

        it('should render title', () => {
            expect(notFound.find('h3').exists()).toBeTruthy()
            expect(notFound.find('h3').text()).toEqual('Page Not Found')
        })
    })
})