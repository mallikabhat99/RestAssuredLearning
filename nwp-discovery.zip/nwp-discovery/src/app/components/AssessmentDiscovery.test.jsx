/* globals expect, beforeEach, describe, it */

import React from 'react'
import { mount } from 'enzyme'

import { AssessmentDiscovery } from '.'
import { AppParts, RequestStatus } from '../entities'

describe('AssessmentDiscovery Component', () => {
    let assessmentDiscoveryProps
    let assessmentDiscovery

    it('should be defined', () => {
        expect(AssessmentDiscovery).toBeDefined()
    })

    describe('Rendering', () => {
        beforeEach(() => {
            assessmentDiscoveryProps = {
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                handleOnChange: jest.fn(),
                onTabChange: jest.fn(),
                match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
                userQuestionSets: [],
                wileyQuestionSets: [],
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.OK
            }
            assessmentDiscovery = mount(<AssessmentDiscovery {...assessmentDiscoveryProps} />)
        })

        it('Should display the header text for create question set or use question set', () => {
            expect(assessmentDiscovery.find('h2[data-testid="assessmentDiscoveryTopPanelHeader1"]').text()).toEqual('Select a question set')
            expect(assessmentDiscovery.find('p[data-testid="assessmentDiscoveryTopPanelHeader2"]').text()).toEqual('You can start with an existing question set or create a new one from scratch')
        })

        it('Should display tabs for question set tabs', () => {
            expect(assessmentDiscovery.find('div[data-testid="assessmentDiscoveryTopPanelTabs"]').exists()).toBeTruthy()
        })

        it('on calling handleOnChange', () => {
            expect(assessmentDiscovery.find('[data-testid="assessmentDiscoveryTopPanelTabs"]').at(0).prop('onChange')())
        })

        it('Render when tab is my question set', () => {
            const mockData = { ...assessmentDiscoveryProps }
            mockData.userQuestionSetsRequestStatus = RequestStatus.PROGRESS
            assessmentDiscovery = mount(<AssessmentDiscovery {...mockData} />)
            expect(assessmentDiscovery.exists()).toBeTruthy()

        })

        it('Render when tab is wiley question set', () => {
            const mockData = { ...assessmentDiscoveryProps }
            mockData.wileyQuestionSetsRequestStatus = RequestStatus.PROGRESS
            assessmentDiscovery = mount(<AssessmentDiscovery {...mockData} />)
            expect(assessmentDiscovery.exists()).toBeTruthy()

        })
    })
})