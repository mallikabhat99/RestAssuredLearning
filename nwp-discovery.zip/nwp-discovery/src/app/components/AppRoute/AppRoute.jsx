import React from 'react'
import PropTypes from 'prop-types'
import { Route, Redirect } from 'react-router-dom'

function AppRoute ({ isReady, path, component: Component, ...rest }) {
    return (
        <Route
            path={path}
            {...rest} render={
                props => (
                    isReady
                        ? <Component {...props} />
                        : <Redirect to={`/configuration${path}`} />
                )
            }
        />
    )
}

AppRoute.propTypes = {
    isReady: PropTypes.bool.isRequired,
    component: PropTypes.any.isRequired,
    path: PropTypes.string
}

export default AppRoute