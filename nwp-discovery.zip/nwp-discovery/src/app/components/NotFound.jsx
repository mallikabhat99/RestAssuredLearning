import React from 'react'

import { Container, Typography } from '@nwp/ui-components'

export default () => (
    <Container component="main">
        <Typography variant="h3">Page Not Found</Typography>
    </Container>
)
