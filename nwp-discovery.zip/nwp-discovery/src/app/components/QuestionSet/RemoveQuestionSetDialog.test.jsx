/* global expect, describe, it, beforeEach */

import React from 'react'
import { mount } from 'enzyme'
import {
    Button,
    Dialog,
    DialogActions,
    DialogContentText,
    DialogTitle
} from '@nwp/ui-components'
import RemoveQuestionSetDialog from './RemoveQuestionSetDialog'

describe('RemoveQuestionSetDialog component', () => {
    let removeQuestionSetDialogProps
    let removeQuestionSetDialog

    it('should be defined', () => {
        expect(RemoveQuestionSetDialog).toBeDefined()
    })

    describe('Rendering removeQuestionSetDialog in closed state', () => {
        beforeEach(() => {
            removeQuestionSetDialogProps = {
                id: 'testid',
                isOpen: false,
                onHandleRemoveApprove: jest.fn(),
                onHandleRemoveDecline: jest.fn()
            }
            removeQuestionSetDialog = mount(<RemoveQuestionSetDialog {...removeQuestionSetDialogProps} />)
        })

        it('should render closed removeQuestionSetDialog', () => {
            const dialog = removeQuestionSetDialog.find(Dialog)

            expect(dialog.exists()).toBeTruthy()
            expect(dialog.prop('open')).toBeFalsy()
        })

    })

    describe('Rendering removeQuestionSetDialog in open state', () => {
        beforeEach(() => {
            removeQuestionSetDialogProps = {
                id: 'testid',
                isOpen: true,
                onHandleRemoveApprove: jest.fn(),
                onHandleRemoveDecline: jest.fn()
            }
            removeQuestionSetDialog = mount(<RemoveQuestionSetDialog {...removeQuestionSetDialogProps} />)
        })

        it('should render open removeQuestionSetDialog', () => {
            const dialog = removeQuestionSetDialog.find(Dialog)

            expect(dialog.exists()).toBeTruthy()
            expect(dialog.prop('open')).toBeTruthy()
        })

        it('should render correct remove dialog title', () => {
            const dialogTitle = removeQuestionSetDialog.find(Dialog).find(DialogTitle)

            expect(dialogTitle.exists()).toBeTruthy()
            expect(dialogTitle.text()).toEqual('Delete question set')
        })

        it('should render correct remove dialog text', () => {
            const dialogContentText = removeQuestionSetDialog.find(Dialog).find(DialogContentText)

            expect(dialogContentText.exists()).toBeTruthy()
            expect(dialogContentText.text()).toEqual('You are about to delete this question set. You won\'t be able to use it in new assignments. Existing assignments will not be impacted.')
        })

        it('should render correct remove dialog buttons', () => {
            const buttons = removeQuestionSetDialog.find(Dialog).find(DialogActions).find(Button)

            // expect(buttons).toHaveLength(2)
            expect(buttons.at(0).text()).toEqual('Cancel')
            expect(buttons.at(1).text()).toEqual('Delete')
        })

        describe('after Cancel remove dialog button click', () => {
            beforeEach(() => {
                removeQuestionSetDialog.find(DialogActions).find(Button).at(0).simulate('click')
            })

            it('should render closed remove dialog', () => {
                expect(removeQuestionSetDialog.prop('open')).toBeFalsy()
            })
        })

        describe('after Remove remove dialog button click', () => {
            beforeEach(() => {
                removeQuestionSetDialog.find(DialogActions).find(Button).at(1).simulate('click')
            })

            it('should render closed remove dialog', () => {
                expect(removeQuestionSetDialog.prop('open')).toBeFalsy()
            })

            it('should call onHandleRemoveApprove', () => {
                expect(removeQuestionSetDialogProps.onHandleRemoveApprove).toHaveBeenCalled()
            })
        })
    })
})