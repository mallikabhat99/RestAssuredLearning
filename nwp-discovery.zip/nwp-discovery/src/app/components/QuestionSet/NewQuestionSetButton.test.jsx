/* globals expect, beforeEach, describe, it */

import React from 'react'
import { mount } from 'enzyme'

import NewQuestionSetButton from './NewQuestionSetButton'

describe('NewQuestionSetButton Component', () => {
    let newQuestionSetButtonProps
    let newQuestionSetButton

    it('should be defined', () => {
        expect(NewQuestionSetButton).toBeDefined()
    })

    describe('Rendering', () => {
        beforeEach(() => {
            newQuestionSetButtonProps = {
                launchId: 'testLaunchId',
                handleNewQuestionSet: jest.fn(),
                openBuilderWindow: jest.fn()
            }
            newQuestionSetButton = mount(<NewQuestionSetButton {...newQuestionSetButtonProps} />)
        })

        it('should render new question set button', () => {
            expect(newQuestionSetButton.find('button[data-testid="assessmentDiscoveryNewQuestionSetButton"]').exists()).toBeTruthy()
            expect(newQuestionSetButton.find('button[data-testid="assessmentDiscoveryNewQuestionSetButton"]').text()).toEqual('NEW QUESTION SET')
        })

        it('should call new question set', () => {
            expect(newQuestionSetButton.find('button[data-testid="assessmentDiscoveryNewQuestionSetButton"]').simulate('click'))
        })
    })
})