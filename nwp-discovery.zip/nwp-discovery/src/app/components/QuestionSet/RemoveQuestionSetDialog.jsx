import React from 'react'
import PropTypes from 'prop-types'
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Typography
} from '@nwp/ui-components'

const RemoveQuestionSetDialog = (
    {
        id,
        isOpen,
        onHandleRemoveApprove,
        onHandleRemoveDecline
    }
) => {

    return (
        <Dialog
            open={isOpen}
            onClose={onHandleRemoveDecline}
            aria-labelledby={`removeQuestionSetDialogTitle${id}`}
            aria-describedby={`removeQuestionSetDialogDescription${id}`}
            data-testid="removeQuestionSetDialog"
        >
            <DialogTitle disableTypography>
                <Typography id={`removeQuestionSetDialogTitle${id}`} variant="h3" data-testid="removeQuestionSetDialogTitle">
                    Delete question set
                </Typography>
            </DialogTitle>
            <DialogContent>
                <DialogContentText id={`removeQuestionSetDialogDescription${id}`} data-testid="removeQuestionSetDialogDescription" variant="body1" color="textPrimary">
                    You are about to delete this question set. You won't be able to use it in new assignments. Existing assignments will not be impacted.
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={onHandleRemoveDecline} color="primary" data-testid="cancelRemoveQuestionSetButton">
                    Cancel
                </Button>
                <Button onClick={onHandleRemoveApprove} color="primary" data-testid="removeQuestionSetButton" autoFocus>
                    Delete
                </Button>
            </DialogActions>
        </Dialog>
    )
}

RemoveQuestionSetDialog.propTypes = {
    id: PropTypes.string.isRequired,
    isOpen: PropTypes.bool.isRequired,

    onHandleRemoveApprove: PropTypes.func.isRequired,
    onHandleRemoveDecline: PropTypes.func.isRequired
}

export default RemoveQuestionSetDialog
