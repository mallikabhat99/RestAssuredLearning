/* globals expect, beforeEach, describe, it */

import React from 'react'
import { mount } from 'enzyme'

import EmptyQuestionSet from './EmptyQuestionSet'
import NewQuestionSetButton from './NewQuestionSetButton'
import { QuestionListBlockedIcon } from '@nwp/ui-components'

describe('EmptyQuestionSet Component', () => {
    let emptyQuestionSetProps
    let emptyQuestionSet

    it('should be defined', () => {
        expect(EmptyQuestionSet).toBeDefined()
    })

    describe('Rendering', () => {
        beforeEach(() => {
            emptyQuestionSetProps = {
                launchId: 'testLaunchId',
                openBuilderWindow: jest.fn()
            }
            emptyQuestionSet = mount(<EmptyQuestionSet {...emptyQuestionSetProps} />)
        })

        it('should render empty question set icon', () => {
            expect(emptyQuestionSet.find(QuestionListBlockedIcon).exists()).toBeTruthy()
        })

        it('should render empty question set message', () => {
            expect(emptyQuestionSet.find('h5').text()).toEqual('You haven\'t added any Question Sets yet')
        })

        it('should render new question set button', () => {
            expect(emptyQuestionSet.find(NewQuestionSetButton).exists()).toBeTruthy()
        })

    })
})