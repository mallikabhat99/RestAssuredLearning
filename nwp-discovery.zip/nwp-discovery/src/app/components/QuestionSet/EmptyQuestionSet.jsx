import React from 'react'
import PropTypes from 'prop-types'

import { Box, QuestionListBlockedIcon, Typography } from '@nwp/ui-components'
import NewQuestionSetButton from './NewQuestionSetButton'

const EmptyQuestionSet = ({ openBuilderWindow }) => {
    return (
        <Box textAlign="center" bgcolor="white" my={6} py={10} border={1} borderColor="grey.200" borderRadius={4} data-testid="assessmentDiscoveryEmptyQuestionSet">
            <QuestionListBlockedIcon width={240} data-testid="assessmentDiscoveryEmptyQuestionSetIcon" />
            <Box pt={6} data-testid="assessmentDiscoveryEmptyQuestionSetMessage">
                <Typography variant="h5">You haven't added any Question Sets yet</Typography>
            </Box>
            <Box pt={8} data-testid="assessmentDiscoveryEmptyQuestionSetNewQuestionSetButton">
                <NewQuestionSetButton openBuilderWindow={openBuilderWindow} />
            </Box>
        </Box>
    )
}

EmptyQuestionSet.propTypes = {
    openBuilderWindow: PropTypes.func.isRequired
}

export default EmptyQuestionSet