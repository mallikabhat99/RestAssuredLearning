/*eslint "no-magic-numbers": ["error", {"ignore": [0, 1, 3, 2, 4, 5, 8, 12, 9, 4.5, 4.75 ]}],*/
import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import { List, AutoSizer, CellMeasurer, CellMeasurerCache, WindowScroller } from 'react-virtualized'
import NewQuestionSetButton from './NewQuestionSetButton'
import EmptyQuestionSet from './EmptyQuestionSet'
import { AppParts, RequestStatus, DefaultPolicy } from '../../entities'
import RemoveQuestionSetDialog from './RemoveQuestionSetDialog'

import { Box, Grid, Typography, Link, Hidden, Button, IconButton, ArrowDropDown, Skeleton, MoreVert, Delete, utils, ContentContainer, FailedToLoad, IconTextField, Search, withStyles, Popover, MenuItem, Tooltip, NoSearchResultsIcon, VpnKey, Timer } from '@nwp/ui-components'

const styles = theme => ({
    questionSetNameColumn: {
        [theme.breakpoints.up('sm')]: {
            maxWidth: '220px'
        },
        [theme.breakpoints.up('md')]: {
            maxWidth: '320px'
        },
        [theme.breakpoints.only('xs')]: {
            order: 1
        }
    },
    questionCountColumn: {
        [theme.breakpoints.up('sm')]: {
            maxWidth: '59px',
            marginLeft: '16px',
            justifyContent: 'flex-end'
        },
        [theme.breakpoints.up('md')]: {
            maxWidth: '60px',
            marginLeft: '21px',
            justifyContent: 'flex-end'
        },
        [theme.breakpoints.only('xs')]: {
            order: 3
        }
    },
    policyColumn: {
        [theme.breakpoints.up('sm')]: {
            maxWidth: '147px',
            marginLeft: '80px'
        },
        [theme.breakpoints.up('md')]: {
            maxWidth: '158px',
            marginLeft: '179px'
        },
        [theme.breakpoints.only('xs')]: {
            order: 4
        }
    },
    buttonColumn: {
        [theme.breakpoints.up('sm')]: {
            maxWidth: '110px',
            marginLeft: '24px'
        },
        [theme.breakpoints.up('md')]: {
            maxWidth: '110px',
            marginLeft: '40px'
        },
        [theme.breakpoints.only('xs')]: {
            order: 5
        }
    },
    buttonColumnWiley: {
        [theme.breakpoints.up('sm')]: {
            maxWidth: '110px',
            marginLeft: '24px'
        },
        [theme.breakpoints.up('md')]: {
            maxWidth: '110px',
            marginLeft: '82px'
        },
        [theme.breakpoints.only('xs')]: {
            order: 5
        }
    },
    actionColumn: {
        maxWidth: '47px',
        [theme.breakpoints.only('xs')]: {
            order: 2,
            '& button': {
                padding: 4
            }
        }
    },
    useSetButton: {
        width: 110,
        height: 36,
        padding: 0,
        border: `1px solid ${theme.palette.grey['100']}`,
        boxSizing: 'border-box',
        borderRadius: 4,
        [theme.breakpoints.only('xs')]: {
            width: '100%',
            marginTop: '12px'
        }
    },
    questionSetContainer: {
        border: `1px solid ${theme.palette.grey['100']}`,
        borderRadius: 4,
        [theme.breakpoints.only('xs')]: {
            border: 'none',
            borderRadius: 0
        }
    },
    questionSetRowContainer: {
        [theme.breakpoints.only('xs')]: {
            border: `1px solid ${theme.palette.grey['100']}`,
            borderRadius: 4,
            marginBottom: '16px'
        }
    },
    boarderHeader: {
        borderBottom: `1px solid ${theme.palette.grey['100']}`
    },
    searchBar: {
        '& .MuiFilledInput-input': {
            paddingTop: theme.spacing(4.75),
            paddingBottom: theme.spacing(4.5),
            backgroundColor: `${theme.palette.primary.contrastText}`,
            '&:hover': {
                backgroundColor: `${theme.palette.primary.contrastText}`
            },
            '&.Mui-focused': {
                backgroundColor: `${theme.palette.primary.contrastText}`
            },
            '&::placeholder': {
                color: theme.palette.grey['400']
            }
        },
        '& .MuiFilledInput-adornedStart': {
            backgroundColor: `${theme.palette.primary.contrastText}`,
            '&:hover': {
                backgroundColor: `${theme.palette.primary.contrastText}`
            },
            '&.Mui-focused': {
                backgroundColor: `${theme.palette.primary.contrastText}`
            }
        },
        '& .MuiFilledInput-adornedEnd': {
            backgroundColor: `${theme.palette.primary.contrastText}`,
            '&:hover': {
                backgroundColor: `${theme.palette.primary.contrastText}`
            },
            '&.Mui-focused': {
                backgroundColor: `${theme.palette.primary.contrastText}`
            }
        }
    },
    searchBarGrid: {
        [theme.breakpoints.only('xs')]: {
            order: 2
        }
    },
    buttonGrid: {
        [theme.breakpoints.only('xs')]: {
            order: 1
        },
        '& button': {
            width: '100%'
        }
    },
    customMenuItem: {
        '&:hover': {
            backgroundColor: theme.palette.grey['50']
        }
    }
})

class QuestionSet extends PureComponent {
    constructor (props) {
        super(props)

        this.cache = new CellMeasurerCache({
            fixedWidth: true,
            defaultHeight: 128
        })

        this.state = {
            useSetPopOver: { anchorEl: null, openedPopoverId: null },
            moreMenuPopOver: { anchorEl: null, openedPopoverId: null },
            removeDialogOpen: false,
            selectedAssessmentToDelete: '',
            inputValue: ''
        }
        this.useSetPopOverId = utils.idGenerator.generateSimpleId('use_set_menu')
        this.moreMenuPopOverId = utils.idGenerator.generateSimpleId('more_menu')
    }

    componentDidUpdate ({ match: prevTab }) {
        const { getQuestionSets, match: { params: { tab: activeTab } } } = this.props
        const { params: { tab: prevActiveTab } } = prevTab
        if (prevActiveTab !== activeTab) {
            this.handleInputValueChange(activeTab, getQuestionSets)
        }
    }

    handleInputValueChange = (activeTab, getQuestionSets) => {
        this.setState({ inputValue: '' })
        getQuestionSets(activeTab)
    }

    handleOpenUseSetMenu = (event, id) => {
        this.setState({ useSetPopOver: { openedPopoverId: id, anchorEl: event.currentTarget } })
    }

    handleCloseUseSetMenu = () => {
        this.setState({ useSetPopOver: { openedPopoverId: null, anchorEl: null } })
    }

    handleOpenMoreMenu = (event, id) => {
        this.setState({ moreMenuPopOver: { openedPopoverId: id, anchorEl: event.currentTarget } })
    }

    handleCloseMoreMenu = () => {
        this.setState({ moreMenuPopOver: { openedPopoverId: null, anchorEl: null } })
    }

    openBuilderWindow = (masterAssessmentId, fromEdit) => {
        const { setSelectedMasterAssessmentId, onPush } = this.props
        const routeValue = fromEdit ? 'edit' : 'create'
        if (masterAssessmentId) {
            setSelectedMasterAssessmentId(masterAssessmentId)
        }
        onPush(`/builder/${routeValue}`)
    }

    handleRetryGetQuestionSets = () => {
        const { getQuestionSets, match: { params: { tab: activeTab } } } = this.props

        getQuestionSets(activeTab)
    }

    handleSearchInputChange = (value) => {
        this.setState({ inputValue: value })
    }

    handleDeleteQuestionSet = (id) => {
        this.setState({
            moreMenuPopOver: { openedPopoverId: null, anchorEl: null },
            removeDialogOpen: true,
            selectedAssessmentToDelete: id
        })
    }

    handleRemoveApprove = ({ id }) => {
        const { deleteAssessment } = this.props
        const { selectedAssessmentToDelete } = this.state

        this.setState({
            removeDialogOpen: false
        })
        deleteAssessment(selectedAssessmentToDelete)
    }

    handleRemoveDecline = () => {
        this.setState({
            removeDialogOpen: false
        })
    }

    renderRow = ({ index, key, style, parent }) => {
        const questionSets = parent.props.questionSets
        const { useSetPopOver, moreMenuPopOver } = this.state
        const {
            match: { params: { tab: activeTab } },
            attachQuestionSet,
            classes
        } = this.props
        const {
            id,
            title,
            items,
            aPolicies
        } = questionSets[index]
        const {
            itemPolicies: {
                timeDurationPolicy: {
                    applicable = false,
                    extraTimeDuration = []
                } = {},
                securityPolicy: {
                    applicable: securityPolicyApplicable
                } = {}
            } = {}
        } = aPolicies || {}
        const timeDurationApplicable = applicable || !!extraTimeDuration.length
        let tooltipText

        if (timeDurationApplicable && securityPolicyApplicable) {
            tooltipText = 'This question set has time and password policies. Duplicate the set to avoid affecting other assignments.'
        } else if (timeDurationApplicable) {
            tooltipText = 'This question set has a time limit. Time limits and time accommodations must be updated before use.'
        } else if (securityPolicyApplicable) {
            tooltipText = 'This question set has a password. Duplicate the set to avoid affecting other assignments\' passwords.'
        }

        return (
            <CellMeasurer
                key={key}
                cache={this.cache}
                parent={parent}
                columnIndex={0}
                rowIndex={index}
            >
                <Box style={style} key={`${id}${index}`} py={{ xs: 4, sm: 4 }} px={{ xs: 4 }} pr={{ sm: activeTab === AppParts.MY_QUESTION_SET.name ? 1 : 4 }} className={classes.questionSetRowContainer}>
                    <Grid container alignItems="center" data-testid="assessmentDiscoveryQuestionSetBody">
                        <Grid item xs={activeTab === AppParts.MY_QUESTION_SET.name ? 8 : 12} sm className={classes.questionSetNameColumn}>
                            <Link underline="none">
                                <Typography variant="body1" fontWeightType="fontWeightSemiBold" data-testid="assessmentDiscoveryQuestionSetNameColumn" breakWord>{title}</Typography>
                            </Link>
                        </Grid>
                        <Grid container item xs={12} sm={1} data-testid="assessmentDiscoveryQuestionSetCountColumn" className={classes.questionCountColumn}>
                            <Typography variant="body1" component="span">{items.length}</Typography>
                            <Hidden only={['sm', 'md', 'lg', 'xl']}><Typography variant="body1" component="span"> questions</Typography></Hidden>
                        </Grid>
                        <Grid container item xs={12} sm={2} data-testid="assessmentDiscoveryQuestionSetPolicyProfileColumn" className={classes.policyColumn}>
                            <Box display="flex" flexDirection="column" width="100%">
                                <Box>
                                    {(aPolicies && aPolicies.profileName)
                                        ? <Typography variant="body1" component="span" breakWord>{aPolicies.profileName}</Typography>
                                        : <Typography variant="body1" component="span" breakWord>{DefaultPolicy.profileName}</Typography>}
                                    <Hidden only={['sm', 'md', 'lg', 'xl']}><Typography variant="body1" component="span"> Policy Profile</Typography></Hidden>
                                </Box>
                                <Box display="flex" flexDirection="row">
                                    {securityPolicyApplicable &&
                                        <Box pt={0.5} pr={2}>
                                            <Tooltip
                                                placement="bottom-start"
                                                data-testid="securityPolicyApplicableInfo"
                                                title={<Box p={2}><Typography variant="caption">Password required</Typography></Box>}
                                            >
                                                <VpnKey data-testid="securityPolicyApplicableInfoIcon" fontSize="small" />
                                            </Tooltip>
                                        </Box>}
                                    {timeDurationApplicable &&
                                        <Box pt={0.5} pr={2}>
                                            <Tooltip
                                                placement="bottom-start"
                                                data-testid="timeDurationPolicyApplicableInfo"
                                                title={<Box p={2}><Typography variant="caption">Time limit set</Typography></Box>}
                                            >
                                                <Timer data-testid="timeDurationPolicyApplicableInfoIcon" fontSize="small" />
                                            </Tooltip>
                                        </Box>}
                                </Box>
                            </Box>
                        </Grid>
                        <Grid
                            container item xs={12} sm={3} md={2} justify="flex-end" data-testid="assessmentDiscoveryQuestionSetDropDownColumn"
                            className={activeTab === AppParts.MY_QUESTION_SET.name ? classes.buttonColumn : classes.buttonColumnWiley}
                        >
                            <Button
                                aria-controls={this.useSetPopOverId}
                                aria-haspopup="true"
                                variant="outlined"
                                data-testid="assessmentDiscoveryQuestionSetDropDownButton"
                                onClick={(event) => this.handleOpenUseSetMenu(event, id)}
                                aria-describedby={id}
                                className={classes.useSetButton}
                            >
                                USE SET <ArrowDropDown data-testid="assessmentDiscoveryQuestionSetDropDownIcon" />
                            </Button>
                            <Popover
                                id={this.useSetPopOverId}
                                anchorEl={useSetPopOver.anchorEl}
                                anchorOrigin={{
                                    vertical: 'bottom',
                                    horizontal: 'left'
                                }}
                                transformOrigin={{
                                    vertical: -8,
                                    horizontal: 58
                                }}
                                open={useSetPopOver.openedPopoverId === id}
                                onClose={this.handleCloseUseSetMenu}
                                PaperProps={{ 'data-testid': 'assessmentDiscoveryUseSetDropDown' }}
                            >
                                <Box py={2}>
                                    {!timeDurationApplicable && !securityPolicyApplicable ? (
                                        <Box className={classes.customMenuItem} data-testid="assessmentDiscoveryUntimedAssignmentButton">
                                            <MenuItem data-testid="assessmentDiscoveryUseSetAsIsButton" color="inherit" onClick={() => attachQuestionSet(id)}>Use as is</MenuItem>
                                        </Box>)
                                        : (
                                            <Tooltip
                                                title={<Box p={2}><Typography variant="caption">{tooltipText}</Typography></Box>}
                                                placement="left"
                                                data-testid="assessmentDiscoveryTimeAssignmentTooltip"
                                            >
                                                <Box className={classes.customMenuItem} color="inherit" data-testid="assessmentDiscoveryAssignmentButton">
                                                    <MenuItem data-testid="assessmentDiscoveryUseSetAsIsButton" disabled={timeDurationApplicable || securityPolicyApplicable}>
                                                        Use as is
                                                    </MenuItem>
                                                </Box>
                                            </Tooltip>)}
                                    <MenuItem data-testid="assessmentDiscoveryModifyAndUseSetButton" onClick={() => this.openBuilderWindow(id, true)}>Duplicate and edit</MenuItem>
                                </Box>
                            </Popover>
                        </Grid>
                        {
                            activeTab === AppParts.MY_QUESTION_SET.name &&
                            <Grid container item xs={4} sm={1} justify="flex-end" data-testid="assessmentDiscoveryQuestionSetElippsisColumn" className={classes.actionColumn}>
                                <IconButton aria-controls={this.moreMenuPopOverId} aria-haspopup="true" fontSize="small" onClick={(event) => this.handleOpenMoreMenu(event, id)}>
                                    <MoreVert data-testid="assessmentDiscoveryQuestionSetElippsisIcon" />
                                </IconButton>
                                <Popover
                                    id={this.moreMenuPopOverId}
                                    anchorEl={moreMenuPopOver.anchorEl}
                                    anchorOrigin={{
                                        vertical: 'bottom',
                                        horizontal: 'left'
                                    }}
                                    transformOrigin={{
                                        vertical: -8,
                                        horizontal: 100
                                    }}
                                    open={moreMenuPopOver.openedPopoverId === id}
                                    onClose={this.handleCloseMoreMenu}
                                    PaperProps={{ 'data-testid': 'questionSetMoreMenu' }}
                                >
                                    <Box py={2}>
                                        <MenuItem data-testid="deleteQuestionSetButton" onClick={() => this.handleDeleteQuestionSet(id)}><Box pr={4} display="inline-flex"><Delete fontSize="small" /></Box>Delete set</MenuItem>
                                    </Box>
                                </Popover>
                            </Grid>
                        }
                    </Grid>
                </Box>
            </CellMeasurer>
        )
    }

    render () {
        const { inputValue } = this.state
        const {
            userQuestionSets,
            wileyQuestionSets,
            match: { params: { tab: activeTab } },
            userQuestionSetsRequestStatus,
            wileyQuestionSetsRequestStatus,
            classes
        } = this.props
        const questionSets = activeTab === AppParts.MY_QUESTION_SET.name ? userQuestionSets : wileyQuestionSets
        let filteredQuestionSets = [...questionSets] || []
        if (inputValue !== '') {
            filteredQuestionSets = questionSets.filter((data) => data.title.toUpperCase().includes(inputValue.toUpperCase()))
        }
        const questionSetsRequestStatus = activeTab === AppParts.MY_QUESTION_SET.name ? userQuestionSetsRequestStatus : wileyQuestionSetsRequestStatus
        return (
            <ContentContainer>
                <RemoveQuestionSetDialog
                    id={this.moreMenuPopOverId}
                    isOpen={this.state.removeDialogOpen}
                    onHandleRemoveApprove={this.handleRemoveApprove}
                    onHandleRemoveDecline={this.handleRemoveDecline}
                />
                <Box pb={6} px={{ xs: 4, sm: 10, md: 0 }}>
                    {
                        (questionSetsRequestStatus !== RequestStatus.OK ||
                            (questionSetsRequestStatus === RequestStatus.OK && filteredQuestionSets && filteredQuestionSets.length > 0) ||
                            (questionSetsRequestStatus === RequestStatus.OK && inputValue)) &&
                            <>
                                {
                                    (questionSetsRequestStatus === RequestStatus.ERROR) &&
                                    <Box textAlign="center" bgcolor="white" my={6} py={10} border={1} borderColor="grey.200" borderRadius={4} data-testid="questionSetErrorContainer">
                                        <FailedToLoad width={235} onTryAgain={this.handleRetryGetQuestionSets}>
                                            <Typography color="textPrimary" variant="h6" data-testid="questionSetErrorMessage">
                                                There was an error loading question sets
                                            </Typography>
                                        </FailedToLoad>
                                    </Box>
                                }
                                {
                                    questionSetsRequestStatus !== RequestStatus.ERROR &&
                                    <>
                                        <Box my={6} data-testid="assessmentDiscoveryQuestionSetSearchNewButton">
                                            <Grid container alignItems="center" spacing={6}>
                                                <Grid
                                                    item xs={12}
                                                    sm={activeTab === AppParts.MY_QUESTION_SET.name ? 8 : 12}
                                                    md={activeTab === AppParts.MY_QUESTION_SET.name ? 9 : 12}
                                                    className={classes.searchBarGrid}
                                                >
                                                    <IconTextField
                                                        inputProps={{ autoComplete: 'off' }}
                                                        placeholder={activeTab === AppParts.MY_QUESTION_SET.name ? 'Search my question sets' : 'Search Wiley question sets'}
                                                        fullWidth
                                                        startIcon={<Search />}
                                                        data-testid="assessmentDiscoveryQuestionSetSearchBar"
                                                        className={classes.searchBar}
                                                        onChange={this.handleSearchInputChange}
                                                        value={inputValue}
                                                    />
                                                </Grid>
                                                {activeTab === AppParts.MY_QUESTION_SET.name &&
                                                <Grid container item justify="flex-end" xs={12} sm={4} md={3} className={classes.buttonGrid}>
                                                    <NewQuestionSetButton
                                                        openBuilderWindow={() => this.openBuilderWindow('', false)}
                                                        data-testid="assessmentDiscoveryNewQuestionSetBtn"
                                                    />
                                                </Grid>}
                                            </Grid>
                                        </Box>
                                        {((inputValue && filteredQuestionSets.length > 0) || (!inputValue)) ? (
                                            <Box
                                                data-testid="assessmentDiscoveryQuestionSetContainer"
                                                bgcolor="common.white"
                                                border={1} borderColor="grey.100" borderRadius={4}
                                                className={classes.questionSetContainer}
                                            >
                                                <Hidden only="xs">
                                                    <Box
                                                        className={classes.boarderHeader}
                                                        py={{ xs: 4, sm: 4 }} px={{ xs: 4 }}
                                                        pr={{ sm: activeTab === AppParts.MY_QUESTION_SET.name ? 1 : 4 }}
                                                    >
                                                        <Grid container alignItems="center" data-testid="assessmentDiscoveryQuestionSetHeader">
                                                            <Grid item sm data-testid="assessmentDiscoveryQuestionSetNameHeader" className={classes.questionSetNameColumn}>
                                                                <Typography variant="caption" fontWeightType="fontWeightSemiBold">Question Set Name</Typography>
                                                            </Grid>
                                                            <Grid container item sm={1} justify="flex-end" data-testid="asssessmentDiscoveryQuestionSetCountHeader" className={classes.questionCountColumn}>
                                                                <Typography variant="caption" fontWeightType="fontWeightSemiBold">Questions</Typography>
                                                            </Grid>
                                                            <Grid item sm={2} data-testid="assessmentDiscoveryQuestionSetPolicyProfileHeader" className={classes.policyColumn}>
                                                                <Typography variant="caption" fontWeightType="fontWeightSemiBold">Policy Profile</Typography>
                                                            </Grid>
                                                            <Grid container item sm={3} md={2} justify="flex-end" className={classes.buttonColumn} />
                                                            {activeTab === AppParts.MY_QUESTION_SET.name && <Grid container item sm={1} justify="flex-end" className={classes.actionColumn} />}
                                                        </Grid>
                                                    </Box>
                                                </Hidden>
                                                {
                                                    questionSetsRequestStatus !== RequestStatus.OK &&
                                                    <Box py={{ xs: 4, sm: 4 }} px={{ xs: 4 }} className={classes.questionSetRowContainer}>
                                                        {[...Array(3).keys()].map(id => (
                                                            <Grid container alignItems="center" data-testid="assessmentDiscoveryQuestionSetBodyLoading" key={id}>
                                                                <Grid item xs={12} sm data-testid="assessmentDiscoveryQuestionSetNameColumnLoading" className={classes.questionSetNameColumn}>
                                                                    <Skeleton variant="text" animation="wave" height={30} width={270} />
                                                                </Grid>
                                                                <Grid container item xs={12} sm data-testid="assessmentDiscoveryQuestionSetCountColumnLoading" className={classes.questionCountColumn}>
                                                                    <Skeleton variant="text" animation="wave" height={30} width={60} />
                                                                </Grid>
                                                                <Grid item xs={12} sm data-testid="assessmentDiscoveryQuestionSetPolicyProfileColumnLoading" className={classes.policyColumn}>
                                                                    <Skeleton variant="text" animation="wave" height={30} width={120} />
                                                                </Grid>
                                                                <Grid
                                                                    container item xs={12} sm justify="flex-end" data-testid="assessmentDiscoveryQuestionSetDropDownColumnLoading"
                                                                    className={activeTab === AppParts.MY_QUESTION_SET.name
                                                                        ? classes.buttonColumn : classes.buttonColumnWiley}
                                                                >
                                                                    <Skeleton variant="text" animation="wave" height={30} width={24} />
                                                                </Grid>
                                                                {
                                                                    activeTab === AppParts.MY_QUESTION_SET.name &&
                                                                    <Grid container item xs={12} sm justify="flex-end" data-testid="assessmentDiscoveryQuestionSetElippsisColumnLoading" className={classes.actionColumn}>
                                                                        <Skeleton variant="text" animation="wave" height={30} width={100} />
                                                                    </Grid>
                                                                }
                                                            </Grid>
                                                        ))}
                                                    </Box>
                                                }
                                                {
                                                    questionSetsRequestStatus === RequestStatus.OK && filteredQuestionSets &&
                                                filteredQuestionSets.length > 0 &&
                                                <Box flexGrow={1} data-testid="questionsSetContent">
                                                    <WindowScroller>
                                                        {
                                                            ({ height, scrollTop }) => (
                                                                <AutoSizer disableHeight>
                                                                    {({ width }) => (
                                                                        <List
                                                                            autoHeight
                                                                            height={height}
                                                                            width={width}
                                                                            scrollTop={scrollTop}
                                                                            rowHeight={this.cache.rowHeight}
                                                                            rowRenderer={this.renderRow}
                                                                            rowCount={filteredQuestionSets.length}
                                                                            overscanRowCount={5}
                                                                            questionSets={{ ...filteredQuestionSets }}
                                                                        />
                                                                    )}
                                                                </AutoSizer>
                                                            )
                                                        }
                                                    </WindowScroller>
                                                </Box>
                                                }
                                            </Box>) : (inputValue &&
                                            <Box display="flex" alignItems="center" justifyContent="center" textAlign="center" height={300} bgcolor="white" my={6} py={10} border={1} borderColor="grey.200" borderRadius={4}>
                                                <Box display="flex" flexDirection="column" alignItems="center">
                                                    <Box maxWidth={500}>
                                                        <NoSearchResultsIcon width="100%" data-testid="emptySearchResultIcon" />
                                                    </Box>
                                                    <Box pt={6} width={200} textAlign="center">
                                                        <Typography color="textPrimary" variant="h6" data-testid="emptySearchResultText">
                                                            No question sets match your search
                                                        </Typography>
                                                    </Box>
                                                </Box>
                                            </Box>)}
                                    </>
                                }
                            </>
                    }
                    {
                        questionSetsRequestStatus === RequestStatus.OK &&
                        (!filteredQuestionSets || (filteredQuestionSets && filteredQuestionSets.length <= 0)) &&
                        activeTab === AppParts.MY_QUESTION_SET.name && !inputValue &&
                        <Box data-testid="assessmentDiscoveryEmptyQuestionPage">
                            <EmptyQuestionSet openBuilderWindow={() => this.openBuilderWindow('', false)} />
                        </Box>
                    }
                </Box>
            </ContentContainer>
        )
    }
}

QuestionSet.propTypes = {
    userQuestionSets: PropTypes.array.isRequired,
    wileyQuestionSets: PropTypes.array.isRequired,
    userQuestionSetsRequestStatus: PropTypes.string.isRequired,
    wileyQuestionSetsRequestStatus: PropTypes.string.isRequired,
    getQuestionSets: PropTypes.func.isRequired,
    attachQuestionSet: PropTypes.func.isRequired,
    match: PropTypes.object.isRequired,
    onPush: PropTypes.func.isRequired,
    setSelectedMasterAssessmentId: PropTypes.func.isRequired,
    classes: PropTypes.object,
    deleteAssessment: PropTypes.func.isRequired
}

export default withStyles(styles)(QuestionSet)