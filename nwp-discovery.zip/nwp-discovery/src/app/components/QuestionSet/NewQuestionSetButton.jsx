import React from 'react'
import PropTypes from 'prop-types'

import { Button, Add } from '@nwp/ui-components'

const NewQuestionSetButton = ({ openBuilderWindow }) => {
    return (
        <Button
            startIcon={<Add />}
            variant="contained"
            color="primary"
            data-testid="assessmentDiscoveryNewQuestionSetButton"
            onClick={openBuilderWindow}
        >NEW QUESTION SET
        </Button>
    )
}

NewQuestionSetButton.propTypes = {
    openBuilderWindow: PropTypes.func.isRequired
}

export default NewQuestionSetButton