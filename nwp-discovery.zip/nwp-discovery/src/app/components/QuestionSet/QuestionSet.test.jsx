/* globals expect, beforeEach, describe, it */

import React from 'react'
import { mount } from 'enzyme'

import { QuestionSet } from '.'
import { AppParts, RequestStatus } from '../../entities'
import { Popover, FailedToLoad, IconButton, IconTextField, Tooltip, Timer, VpnKey } from '@nwp/ui-components'
import NewQuestionSetButton from './NewQuestionSetButton'
import { List } from 'react-virtualized'
import EmptyQuestionSet from './EmptyQuestionSet'
import RemoveQuestionSetDialog from './RemoveQuestionSetDialog'

describe('QuestionSet Component', () => {
    let questionSetProps
    let questionSet

    it('should be defined', () => {
        expect(QuestionSet).toBeDefined()
    })

    describe('Rendering', () => {
        beforeEach(() => {
            questionSetProps = {
                match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
                wileyQuestionSets: [],
                userQuestionSets: [
                    {
                        id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: false,
                                    duration: 88
                                }
                            }
                        }
                    },
                    {
                        id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: 'Custom',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: false,
                                    duration: 5
                                }
                            }
                        }
                    }
                ],
                launchId: 'testLaunchId',
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                attachQuestionSet: jest.fn(),
                deleteAssessment: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn(),
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.INITIAL
            }
            questionSet = mount(<QuestionSet {...questionSetProps} />)
        })

        it('Should display the both search and new question set for "my question set" tab', () => {
            expect(questionSet.find('div[data-testid="assessmentDiscoveryQuestionSetSearchNewButton"]').exists()).toBeTruthy()
        })
        it('Should display wiley question set on tab select', () => {
            questionSet.setProps({ match: { params: { tab: AppParts.WILEY_QUESTION_SET.name } } })
            expect(questionSet.find('div[data-testid="assessmentDiscoveryQuestionSetSearchNewButton"]').exists()).toBeTruthy()
        })

        it('Should display empty question set if no result', () => {
            questionSet.setProps({ userQuestionSets: [], userQuestionSetsRequestStatus: RequestStatus.OK })
            expect(questionSet.find('div[data-testid="assessmentDiscoveryEmptyQuestionPage"]').exists()).toBeTruthy()
        })

        it('should call openBuilderWindow function', () => {
            expect(questionSet.find(NewQuestionSetButton).at(0).prop('openBuilderWindow')())
        })

        it('should call handleRemoveApprove function', () => {
            expect(questionSet.find(RemoveQuestionSetDialog).at(0).prop('onHandleRemoveApprove')('id'))
        })

        it('should call handleRemoveDecline function', () => {
            expect(questionSet.find(RemoveQuestionSetDialog).at(0).prop('onHandleRemoveDecline')())
        })

        it('should render FailedToLoad component', () => {
            const mock = { ...questionSetProps }
            mock.match = { params: { tab: AppParts.WILEY_QUESTION_SET.name } }
            mock.wileyQuestionSetsRequestStatus = RequestStatus.ERROR
            questionSet = mount(<QuestionSet {...mock} />)

            expect(questionSet.find(FailedToLoad).exists()).toBeTruthy()
        })

        it('should call handleRetryGetQuestionSets on Try again', () => {
            const mock = { ...questionSetProps }
            mock.match = { params: { tab: AppParts.WILEY_QUESTION_SET.name } }
            mock.wileyQuestionSetsRequestStatus = RequestStatus.ERROR
            questionSet = mount(<QuestionSet {...mock} />)

            expect(questionSet.find(FailedToLoad).prop('onTryAgain')())
        })
        it('Render when active tab is My question set', () => {
            const mock = { ...questionSetProps }
            mock.match = { params: { tab: AppParts.MY_QUESTION_SET.name } }
            mock.userQuestionSetsRequestStatus = RequestStatus.INITIAL
            questionSet = mount(<QuestionSet {...mock} />)

            expect(questionSet.find('div[data-testid="assessmentDiscoveryQuestionSetElippsisColumnLoading"]').exists()).toBeTruthy()
        })

        it('Render when tab is wiley question set', () => {
            const mock = { ...questionSetProps }
            mock.match = { params: { tab: AppParts.WILEY_QUESTION_SET.name } }
            mock.wileyQuestionSetsRequestStatus = RequestStatus.INITIAL
            mock.wileyQuestionSets = [
                {
                    id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                    title: 'Copy of Accommodated Qset',
                    items: [],
                    aPolicies: {
                        profileName: '',
                        itemPolicies: {
                            timeDurationPolicy: {
                                applicable: false,
                                duration: 88
                            }
                        }
                    }
                },
                {
                    id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                    title: 'Copy of Accommodated Qset',
                    items: [],
                    aPolicies: {
                        profileName: 'Custom',
                        itemPolicies: {
                            timeDurationPolicy: {
                                applicable: false,
                                duration: 5
                            }
                        }
                    }
                }
            ]
            questionSet = mount(<QuestionSet {...mock} />)
            expect(questionSet.find('div[data-testid="assessmentDiscoveryQuestionSetDropDownColumnLoading"]').exists()).toBeTruthy()
        })

        it('Should call openBuilderWindow function in EmptyQuestionSet when active tab is My question set', () => {
            const mock = { ...questionSetProps }
            mock.match = { params: { tab: AppParts.MY_QUESTION_SET.name } }
            mock.userQuestionSetsRequestStatus = RequestStatus.OK
            mock.userQuestionSets = []
            questionSet = mount(<QuestionSet {...mock} />)
            expect(questionSet.find(EmptyQuestionSet).prop('openBuilderWindow')())
        })
    })

    describe('Rendering', () => {
        beforeEach(() => {
            questionSetProps = {
                match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
                wileyQuestionSets: [],
                userQuestionSets: [
                    {
                        id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: true,
                                    duration: 88
                                }
                            }
                        }
                    },
                    {
                        id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: 'Custom',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: true,
                                    duration: 5
                                }
                            }
                        }
                    }
                ],
                launchId: 'testLaunchId',
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                attachQuestionSet: jest.fn(),
                deleteAssessment: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn(),
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.INITIAL
            }
            questionSet = mount(<QuestionSet {...questionSetProps} />)
        })

        it('Should display the both search and new question set for "my question set" tab', () => {
            questionSet.find(IconTextField).at(0).prop('onChange')('VALUE')
            expect(questionSet.find('div[data-testid="assessmentDiscoveryQuestionSetSearchBar"]').exists()).toBeTruthy()
        })
    })

    describe('Rendering', () => {
        beforeEach(() => {
            questionSetProps = {
                match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
                wileyQuestionSets: [],
                userQuestionSets: [
                    {
                        id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: 'Custom',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: false,
                                    duration: 88
                                }
                            }
                        }
                    },
                    {
                        id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: 'Custom',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: false,
                                    duration: 5
                                }
                            }
                        }
                    }
                ],
                launchId: 'testLaunchId',
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                deleteAssessment: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn(),
                attachQuestionSet: jest.fn(),
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.INITIAL
            }
            questionSet = mount(<QuestionSet {...questionSetProps} />)
        })
        describe('Virtualized list item rendering', () => {
            let virtualizedListItem

            beforeEach(() => {
                virtualizedListItem = mount(questionSet.find(List).prop('rowRenderer')({
                    index: 0,
                    key: 0,
                    style: {},
                    parent: {
                        props: {
                            questionSets: [
                                {
                                    id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                                    title: 'Copy of Accommodated Qset',
                                    items: [],
                                    aPolicies: {
                                        profileName: 'Custom',
                                        itemPolicies: {
                                            timeDurationPolicy: {
                                                applicable: false,
                                                duration: 88
                                            }
                                        }
                                    }
                                },
                                {
                                    id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                                    title: 'Copy of Accommodated Qset',
                                    items: [],
                                    aPolicies: {
                                        profileName: 'Custom',
                                        itemPolicies: {
                                            timeDurationPolicy: {
                                                applicable: false,
                                                duration: 5
                                            }
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }))
            })

            it('should call handleOpenMenu', () => {
                expect(virtualizedListItem.find('button[data-testid="assessmentDiscoveryQuestionSetDropDownButton"]').at(0).simulate('click'))
            })
            it('on calling handleOnChange handleCloseMenu has to be triggered', () => {
                expect(virtualizedListItem.find(Popover).at(0).prop('onClose')())
            })

            it('should call handleOpenMoreMenu function', () => {
                expect(virtualizedListItem.find(IconButton).at(0).simulate('click'))
            })

            it('should call handleCloseMoreMenu function ', () => {
                expect(virtualizedListItem.find(Popover).at(1).prop('onClose')())
            })

            it('should not display time duration and security applicable icon', () => {
                expect(virtualizedListItem.find(Timer).exists()).toBeFalsy()
                expect(virtualizedListItem.find(VpnKey).exists()).toBeFalsy()
            })
        })
    })

    describe('Rendering when active tab is wiley question set', () => {

        beforeEach(() => {
            questionSetProps = {
                match: { params: { tab: AppParts.WILEY_QUESTION_SET.name } },
                userQuestionSets: [],
                wileyQuestionSets: [
                    {
                        id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: true,
                                    duration: 88
                                }
                            }
                        }
                    },
                    {
                        id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: 'Custom',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: true,
                                    duration: 5
                                }
                            }
                        }
                    }
                ],
                launchId: 'testLaunchId',
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                attachQuestionSet: jest.fn(),
                deleteAssessment: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn(),
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.OK
            }
            questionSet = mount(<QuestionSet {...questionSetProps} />)
        })
        describe('Virtualized list item rendering when active tab is wiley question set', () => {
            let question

            beforeEach(() => {
                question = mount(questionSet.find(List).prop('rowRenderer')({
                    index: 0,
                    key: 0,
                    style: {},
                    parent: {
                        props: {
                            questionSets: [
                                {
                                    id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                                    title: 'Copy of Accommodated Qset',
                                    items: [],
                                    aPolicies: {
                                        profileName: '',
                                        itemPolicies: {
                                            timeDurationPolicy: {
                                                applicable: true,
                                                duration: 88
                                            }
                                        }
                                    }
                                },
                                {
                                    id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                                    title: 'Copy of Accommodated Qset',
                                    items: [],
                                    aPolicies: {
                                        profileName: 'Custom',
                                        itemPolicies: {
                                            timeDurationPolicy: {
                                                applicable: true,
                                                duration: 5
                                            }
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }))
            })

            it('Rendering List Item', () => {
                expect(question.exists()).toBeTruthy()
            })
        })
    })

    describe('Rendering when aPolicies is null', () => {
        beforeEach(() => {
            questionSetProps = {
                match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
                wileyQuestionSets: [],
                userQuestionSets: [
                    {
                        id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: false,
                                    duration: 88
                                }
                            }
                        }
                    },
                    {
                        id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: false,
                                    duration: 88
                                }
                            }
                        }
                    }
                ],
                launchId: 'testLaunchId',
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                attachQuestionSet: jest.fn(),
                deleteAssessment: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn(),
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.INITIAL
            }
            questionSet = mount(<QuestionSet {...questionSetProps} />)
        })
        describe('Virtualized list item rendering', () => {
            let virtualizedListItem

            beforeEach(() => {
                virtualizedListItem = mount(questionSet.find(List).prop('rowRenderer')({
                    index: 0,
                    key: 0,
                    style: {},
                    parent: {
                        props: {
                            questionSets: [
                                {
                                    id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                                    title: 'Copy of Accommodated Qset',
                                    items: [],
                                    aPolicies: null
                                },
                                {
                                    id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                                    title: 'Copy of Accommodated Qset',
                                    items: [],
                                    aPolicies: null
                                }
                            ]
                        }
                    }
                }))
            })

            it('should have virtualized list', () => {
                expect(virtualizedListItem.exists()).toBeTruthy()
            })

        })
    })

    describe('Rendering when securityPolicy enabled', () => {
        beforeEach(() => {
            questionSetProps = {
                match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
                wileyQuestionSets: [],
                userQuestionSets: [
                    {
                        id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: false,
                                    duration: 88
                                },
                                securityPolicy: {
                                    applicable: true
                                }
                            }
                        }
                    }
                ],
                launchId: 'testLaunchId',
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                attachQuestionSet: jest.fn(),
                deleteAssessment: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn(),
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.INITIAL
            }
            questionSet = mount(<QuestionSet {...questionSetProps} />)
        })
        describe('Virtualized list item rendering', () => {
            let virtualizedListItem
            const virtualizedListItemProps = {
                index: 0,
                key: 0,
                style: {},
                parent: {
                    props: {
                        questionSets: [
                            {
                                id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                                title: 'Copy of Accommodated Qset',
                                items: [],
                                aPolicies: {
                                    profileName: '',
                                    itemPolicies: {
                                        timeDurationPolicy: {
                                            applicable: false,
                                            duration: 88
                                        },
                                        securityPolicy: {
                                            applicable: true
                                        }
                                    }
                                }
                            }
                        ]
                    }
                }
            }
            beforeEach(() => {
                virtualizedListItem = mount(questionSet.find(List).prop('rowRenderer')(virtualizedListItemProps))
            })

            it('should have virtualized list', () => {
                expect(virtualizedListItem.exists()).toBeTruthy()
            })

            describe('After use set dropdown click', () => {
                beforeEach(() => {
                    virtualizedListItem.find('button[data-testid="assessmentDiscoveryQuestionSetDropDownButton"]').at(0).simulate('click')
                    virtualizedListItem.update()
                })
                it('should render use as menu with proper tool tip', () => {
                    virtualizedListItem = mount(questionSet.find(List).prop('rowRenderer')(virtualizedListItemProps))
                    const assessmentDiscoveryTimeAssignmentTooltip = virtualizedListItem.find('[data-testid="assessmentDiscoveryTimeAssignmentTooltip"]').at(0)
                    expect(assessmentDiscoveryTimeAssignmentTooltip.exists()).toBeTruthy()
                    expect(mount(assessmentDiscoveryTimeAssignmentTooltip.prop('title')).text()).toEqual('This question set has a password. Duplicate the set to avoid affecting other assignments\' passwords.')
                })
            })
        })
    })

    describe('Rendering when securityPolicy and timeDurationPolicy enabled ', () => {
        beforeEach(() => {
            questionSetProps = {
                match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
                wileyQuestionSets: [],
                userQuestionSets: [
                    {
                        id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: true,
                                    duration: 88
                                },
                                securityPolicy: {
                                    applicable: true
                                }
                            }
                        }
                    }
                ],
                launchId: 'testLaunchId',
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                attachQuestionSet: jest.fn(),
                deleteAssessment: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn(),
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.INITIAL
            }
            questionSet = mount(<QuestionSet {...questionSetProps} />)
        })
        describe('Virtualized list item rendering', () => {
            let virtualizedListItem
            const virtualizedListItemProps = {
                index: 0,
                key: 0,
                style: {},
                parent: {
                    props: {
                        questionSets: [
                            {
                                id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                                title: 'Copy of Accommodated Qset',
                                items: [],
                                aPolicies: {
                                    profileName: '',
                                    itemPolicies: {
                                        timeDurationPolicy: {
                                            applicable: true,
                                            duration: 88
                                        },
                                        securityPolicy: {
                                            applicable: true
                                        }
                                    }
                                }
                            }
                        ]
                    }
                }
            }

            beforeEach(() => {
                virtualizedListItem = mount(questionSet.find(List).prop('rowRenderer')(virtualizedListItemProps))
            })

            it('should have virtualized list', () => {
                expect(virtualizedListItem.exists()).toBeTruthy()
            })

            describe('After use set dropdown click', () => {
                beforeEach(() => {
                    virtualizedListItem.find('button[data-testid="assessmentDiscoveryQuestionSetDropDownButton"]').at(0).simulate('click')
                    virtualizedListItem.update()
                })
                it('should render use as menu with proper tool tip', () => {
                    virtualizedListItem = mount(questionSet.find(List).prop('rowRenderer')(virtualizedListItemProps))
                    const assessmentDiscoveryTimeAssignmentTooltip = virtualizedListItem.find('[data-testid="assessmentDiscoveryTimeAssignmentTooltip"]').at(0)
                    expect(assessmentDiscoveryTimeAssignmentTooltip.exists()).toBeTruthy()
                    expect(mount(assessmentDiscoveryTimeAssignmentTooltip.prop('title')).text()).toEqual('This question set has time and password policies. Duplicate the set to avoid affecting other assignments.')
                })
            })
        })
    })

    describe('Rendering applicable policies info', () => {
        beforeEach(() => {
            questionSetProps = {
                match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
                wileyQuestionSets: [],
                userQuestionSets: [
                    {
                        id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: true,
                                    duration: 88
                                }
                            }
                        }
                    },
                    {
                        id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                        title: 'Copy of Accommodated Qset',
                        items: [],
                        aPolicies: {
                            profileName: '',
                            itemPolicies: {
                                timeDurationPolicy: {
                                    applicable: true,
                                    duration: 88
                                }
                            }
                        }
                    }
                ],
                launchId: 'testLaunchId',
                getQuestionSets: jest.fn(),
                onPush: jest.fn(),
                attachQuestionSet: jest.fn(),
                deleteAssessment: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn(),
                userQuestionSetsRequestStatus: RequestStatus.OK,
                wileyQuestionSetsRequestStatus: RequestStatus.INITIAL
            }
            questionSet = mount(<QuestionSet {...questionSetProps} />)
        })
        describe('Virtualized list item rendering', () => {
            let virtualizedListItem

            beforeEach(() => {
                virtualizedListItem = mount(questionSet.find(List).prop('rowRenderer')({
                    index: 0,
                    key: 0,
                    style: {},
                    parent: {
                        props: {
                            questionSets: [
                                {
                                    id: '00048d6b-77a6-4a9b-8e1d-2ed54b44f6a0',
                                    title: 'Copy of Accommodated Qset',
                                    items: [],
                                    aPolicies: {
                                        profileName: '',
                                        itemPolicies: {
                                            timeDurationPolicy: {
                                                applicable: true,
                                                duration: 88
                                            },
                                            securityPolicy: {
                                                applicable: true,
                                                password: '#Hi89yujb'
                                            }
                                        }
                                    }
                                },
                                {
                                    id: '18c2cc0e-c70d-4fd7-adc1-df5c244f0d31',
                                    title: 'Copy of Accommodated Qset',
                                    items: [],
                                    aPolicies: {
                                        profileName: 'Custom',
                                        itemPolicies: {
                                            timeDurationPolicy: {
                                                applicable: true,
                                                duration: 5
                                            }
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }))
            })

            it('should display time duration applicable tool tip and icon', () => {
                expect(mount(virtualizedListItem.find(Tooltip).at(1).prop('title')).text()).toEqual('Time limit set')
                expect(virtualizedListItem.find(Timer).exists()).toBeTruthy()
            })

            it('should display security policy applicable tool tip and icon', () => {
                expect(mount(virtualizedListItem.find(Tooltip).at(0).prop('title')).text()).toEqual('Password required')
                expect(virtualizedListItem.find(VpnKey).exists()).toBeTruthy()
            })
        })
    })
})
