import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'

import {
    Box,
    Typography,
    Button,
    ContentContainer
} from '@nwp/ui-components'

import { RequestStatus, AppProperties } from '../../entities'
import CancelQuestionSetUpdateDialog from './CancelQuestionSetUpdateDialog'

class QuestionSetBuilder extends PureComponent {

    constructor (props) {
        super(props)
        this.builderWindow = null
        this.state = {
            cancelDialogOpen: false
        }
    }

    componentDidMount () {
        const { launchId, setToLocalStorage } = this.props

        this.openBuilder()
        setToLocalStorage(launchId, {status: RequestStatus.INITIAL, origin: AppProperties.APP_NAME})
        window.addEventListener('storage', this.handleStorageEvent, false)
        window.addEventListener('beforeunload', this.handleLocalStorageDelete)
    }

    componentWillUnmount () {
        this.handleLocalStorageDelete()
        window.removeEventListener('storage', this.handleStorageEvent, false)
        window.removeEventListener('beforeunload', this.handleLocalStorageDelete)
    }

    handleStorageEvent = ({ key, newValue }) => {
        const { launchId, attachQuestionSet } = this.props

        if (key === launchId && JSON.parse(newValue).status === RequestStatus.OK) {
            attachQuestionSet(JSON.parse(newValue).masterAssessmentId)
            this.handleLocalStorageDelete()
        }
    }

    handleContinue = () => {
        if (this.builderWindow && !this.builderWindow.closed) {
            this.builderWindow.focus()
        } else {
            this.openBuilder()
        }
    }

    handleCancel = () => {
        this.setState({ cancelDialogOpen: true })
    }

    openBuilder = () => {
        const { launchId, selectedMasterAssessmentId } = this.props

        if (selectedMasterAssessmentId) {
            this.builderWindow = window.open(`/was/ui/v2/assessment-builder/index.html?launchId=${launchId}&masterAssessmentId=${selectedMasterAssessmentId}`, '_blank')
        } else {
            this.builderWindow = window.open(`/was/ui/v2/assessment-builder/index.html?launchId=${launchId}`, '_blank')
        }
    }

    handleCancelApprove = () => {
        const { onPush, setSelectedMasterAssessmentId } = this.props

        this.setState({ cancelDialogOpen: false })
        this.handleLocalStorageDelete()
        setSelectedMasterAssessmentId('')
        onPush('/discovery/author')
    }

    handleCancelDecline = () => {
        this.setState({ cancelDialogOpen: false })
    }

    handleLocalStorageDelete = () => {
        const { launchId, removeFromLocalStorage } = this.props

        if (this.builderWindow && !this.builderWindow.closed) {
            this.builderWindow.close()
        }
        removeFromLocalStorage(launchId)
        removeFromLocalStorage(`assessmentBuilderState${launchId}`)
    }

    render () {
        const {
            match: { params: { tab } }
        } = this.props

        return (
            <ContentContainer>
                <CancelQuestionSetUpdateDialog
                    isOpen={this.state.cancelDialogOpen}
                    isFromCreate={tab === 'create'}
                    onHandleCancelApprove={this.handleCancelApprove}
                    onHandleCancelDecline={this.handleCancelDecline}
                />
                <Box data-testid="questionSetBuildingProgressContainer" display="flex" flexDirection="column" justifyContent="center" alignItems="center">
                    <Box my={10}>
                        <Typography color="textPrimary" variant="h2" data-testid="questionSetBuildingProgressMessage">
                            {tab === 'create' ? 'You\'re creating a question set in another tab' : 'You\'re editing this question set in another tab'}
                        </Typography>
                    </Box>
                    <Box>
                        <Box mr={8} display="inline-block">
                            <Button variant="outlined" data-testid="questionSetBuildingProgressCancelButton" onClick={this.handleCancel}>
                                Close Tab
                            </Button>
                        </Box>
                        <Box display="inline-block">
                            <Button variant="outlined" data-testid="questionSetBuildingProgressContinueButton" onClick={this.handleContinue}>
                                {tab === 'create' ? 'CONTINUE CREATING' : 'CONTINUE EDITING'}
                            </Button>
                        </Box>
                    </Box>
                </Box>
            </ContentContainer>
        )
    }
}

QuestionSetBuilder.propTypes = {
    launchId: PropTypes.string.isRequired,
    selectedMasterAssessmentId: PropTypes.string.isRequired,
    setSelectedMasterAssessmentId: PropTypes.func.isRequired,
    attachQuestionSet: PropTypes.func.isRequired,
    setToLocalStorage: PropTypes.func.isRequired,
    removeFromLocalStorage: PropTypes.func.isRequired,
    match: PropTypes.object.isRequired,
    onPush: PropTypes.func.isRequired
}

export default QuestionSetBuilder