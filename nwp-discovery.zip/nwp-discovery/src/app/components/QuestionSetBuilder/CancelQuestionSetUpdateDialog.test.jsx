/* global expect, describe, it, beforeEach */

import React from 'react'
import { mount } from 'enzyme'
import {
    Button,
    Dialog,
    DialogActions,
    DialogContentText,
    DialogTitle
} from '@nwp/ui-components'
import CancelQuestionSetUpdateDialog from './CancelQuestionSetUpdateDialog'

describe('CancelQuestionSetUpdateDialog component', () => {
    let cancelQuestionSetUpdateDialogProps
    let cancelQuestionSetUpdateDialog

    it('should be defined', () => {
        expect(CancelQuestionSetUpdateDialog).toBeDefined()
    })

    describe('Rendering cancelQuestionSetUpdateDialog in closed state', () => {
        beforeEach(() => {
            cancelQuestionSetUpdateDialogProps = {
                isOpen: false,
                isFromCreate: true,
                onHandleCancelApprove: jest.fn(),
                onHandleCancelDecline: jest.fn()
            }
            cancelQuestionSetUpdateDialog = mount(<CancelQuestionSetUpdateDialog {...cancelQuestionSetUpdateDialogProps} />)
        })

        it('should render closed cancelQuestionSetUpdateDialog', () => {
            const dialog = cancelQuestionSetUpdateDialog.find(Dialog)

            expect(dialog.exists()).toBeTruthy()
            expect(dialog.prop('open')).toBeFalsy()
        })

    })

    describe('Rendering cancelQuestionSetUpdateDialog in open state', () => {
        beforeEach(() => {
            cancelQuestionSetUpdateDialogProps = {
                isOpen: true,
                isFromCreate: true,
                onHandleCancelApprove: jest.fn(),
                onHandleCancelDecline: jest.fn()
            }
            cancelQuestionSetUpdateDialog = mount(<CancelQuestionSetUpdateDialog {...cancelQuestionSetUpdateDialogProps} />)
        })

        it('should render open cancelQuestionSetUpdateDialog', () => {
            const dialog = cancelQuestionSetUpdateDialog.find(Dialog)

            expect(dialog.exists()).toBeTruthy()
            expect(dialog.prop('open')).toBeTruthy()
        })

        it('should render correct remove dialog title', () => {
            const dialogTitle = cancelQuestionSetUpdateDialog.find(Dialog).find(DialogTitle)

            expect(dialogTitle.exists()).toBeTruthy()
            expect(dialogTitle.text()).toEqual('Close question set tab')
        })

        it('should render correct remove dialog text', () => {
            const dialogContentText = cancelQuestionSetUpdateDialog.find(Dialog).find(DialogContentText)

            expect(dialogContentText.exists()).toBeTruthy()
            expect(dialogContentText.text()).toEqual('The question set will be discarded. Are you sure you want to close the tab?')
        })

        it('should render correct remove dialog buttons', () => {
            const buttons = cancelQuestionSetUpdateDialog.find(Dialog).find(DialogActions).find(Button)

            // expect(buttons).toHaveLength(2)
            expect(buttons.at(0).text()).toEqual('Cancel')
            expect(buttons.at(1).text()).toEqual('Close Tab')
        })

        describe('after Cancel remove dialog button click', () => {
            beforeEach(() => {
                cancelQuestionSetUpdateDialog.find(DialogActions).find(Button).at(0).simulate('click')
            })

            it('should render closed remove dialog', () => {
                expect(cancelQuestionSetUpdateDialog.prop('open')).toBeFalsy()
            })
        })

        describe('after Remove remove dialog button click', () => {
            beforeEach(() => {
                cancelQuestionSetUpdateDialog.find(DialogActions).find(Button).at(1).simulate('click')
            })

            it('should render closed remove dialog', () => {
                expect(cancelQuestionSetUpdateDialog.prop('open')).toBeFalsy()
            })

            it('should call onHandleCancelApprove', () => {
                expect(cancelQuestionSetUpdateDialogProps.onHandleCancelApprove).toHaveBeenCalled()
            })
        })
    })
})