/* globals expect, beforeEach, describe, it */

import React from 'react'
import { mount } from 'enzyme'
import { shallowToJson } from 'enzyme-to-json'

import QuestionSetBuilder from './QuestionSetBuilder'
import CancelQuestionSetUpdateDialog from './CancelQuestionSetUpdateDialog'
import { RequestStatus } from '../../entities'

describe('QuestionSetBuilder Component', () => {
    let questionsetBuilder
    let questionsetBuilderProps
    window.open = jest.fn()

    it('should be defined', () => {
        expect(QuestionSetBuilder).toBeDefined()
    })

    describe('Rendering', () => {
        beforeEach(() => {
            questionsetBuilderProps = {
                match: { params: { tab: 'create' } },
                launchId: 'testLaunchId',
                selectedMasterAssessmentId: 'masterAssessmentId',
                handleStorageEvent: jest.fn(),
                attachQuestionSet: jest.fn(),
                setToLocalStorage: jest.fn(),
                removeFromLocalStorage: jest.fn(),
                onPush: jest.fn(),
                setSelectedMasterAssessmentId: jest.fn()
            }
            questionsetBuilder = mount(<QuestionSetBuilder {...questionsetBuilderProps} />)
            questionsetBuilder.instance().builderWindow = { close: jest.fn(), focus: jest.fn() }
        })

        it('Should render QuestionSetBuilder component', () => {
            expect(questionsetBuilder.exists()).toBeTruthy()
        })

        it('should call builderWindow focus change on handleContinue event', () => {
            questionsetBuilder.find('button[data-testid="questionSetBuildingProgressContinueButton"]').at(0).simulate('click')
            expect(questionsetBuilder.instance().builderWindow.focus).toHaveBeenCalled()
        })

        it('should call handleStorageEvent function', () => {
            expect(questionsetBuilder.instance().handleStorageEvent({ key: 'testLaunchId', newValue: JSON.stringify({ status: RequestStatus.OK }) }))
        })

        it('In handleStorageEvent event key should not be equal to launchId and status should be "ok"', () => {
            expect(questionsetBuilder.instance().handleStorageEvent({ key: 'id', newValue: JSON.stringify({ status: RequestStatus.INITIAL }) }))
        })

        it('should call handleCancel function', () => {
            expect(questionsetBuilder.instance().handleCancel())
        })

        it('should have selectedMasterAssessmentId null in openBuilder function', () => {
            const mock = { ...questionsetBuilderProps }
            mock.selectedMasterAssessmentId = ''
            questionsetBuilder = mount(<QuestionSetBuilder {...mock} />)
            expect(questionsetBuilder.exists()).toBeTruthy()
        })

        it('to mock componentWillUnmount', () => {
            questionsetBuilder.instance().componentWillUnmount()
            expect(shallowToJson(questionsetBuilder)).toBeTruthy()
        })

        it('Render when tab is editing', () => {
            const mock = { ...questionsetBuilderProps }
            mock.match = { params: { tab: 'editing' } }
            questionsetBuilder = mount(<QuestionSetBuilder {...mock} />)
            expect(questionsetBuilder.exists()).toBeTruthy()
        })

        it('should call handleCancelApprove  function', () => {
            questionsetBuilder.instance().handleCancelApprove()
            expect(questionsetBuilder.find(CancelQuestionSetUpdateDialog).exists()).toBeTruthy()
        })

        it('should call handleCancelDecline function', () => {
            questionsetBuilder.instance().handleCancelDecline()
            expect(questionsetBuilder.find(CancelQuestionSetUpdateDialog).exists()).toBeTruthy()
        })
    })

    describe('Rendering', () => {
        beforeEach(() => {
            questionsetBuilderProps = {
                match: { params: { tab: 'create' } },
                launchId: 'testLaunchId',
                value: false,
                selectedMasterAssessmentId: 'masterAssessmentId',
                handleStorageEvent: jest.fn(),
                attachQuestionSet: jest.fn(),
                setToLocalStorage: jest.fn(),
                removeFromLocalStorage: jest.fn(),
                onPush: jest.fn()
            }
            questionsetBuilder = mount(<QuestionSetBuilder {...questionsetBuilderProps} />)
        })

        it('should call handleContinue function', () => {
            questionsetBuilder.instance().handleContinue()
            expect(questionsetBuilder.find('button[data-testid="questionSetBuildingProgressContinueButton"]').exists()).toBeTruthy()
        })

        it('should call handleLocalStorageDelete function', () => {
            expect(questionsetBuilder.instance().handleLocalStorageDelete())
        })
    })
})