import React from 'react'
import PropTypes from 'prop-types'
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Typography
} from '@nwp/ui-components'

const CancelQuestionSetUpdateDialog = (
    {
        isOpen,
        isFromCreate,
        onHandleCancelApprove,
        onHandleCancelDecline
    }
) => {

    return (
        <Dialog
            open={isOpen}
            onClose={onHandleCancelDecline}
            aria-labelledby="cancelQuestionSetUpdateDialogTitle"
            aria-describedby="cancelQuestionSetUpdateDialogDescription"
            data-testid="cancelQuestionSetUpdateDialog"
        >
            <DialogTitle disableTypography>
                <Typography id="cancelQuestionSetUpdateDialogTitle" variant="h3" data-testid="cancelQuestionSetUpdateDialogTitle">
                    Close question set tab
                </Typography>
            </DialogTitle>
            <DialogContent>
                <DialogContentText id="cancelQuestionSetUpdateDialogDescription" data-testid="cancelQuestionSetUpdateDialogDescription" variant="body1" color="textPrimary">
                    {isFromCreate
                        ? 'The question set will be discarded. Are you sure you want to close the tab?'
                        : 'Changes you made to the question set will be discarded. Are you sure you want to close the tab?'}

                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={onHandleCancelDecline} color="primary" data-testid="cancelQuestionSetUpdateButton">
                    Cancel
                </Button>
                <Button onClick={onHandleCancelApprove} color="primary" data-testid="closeAssessmentBuilderTabButton" autoFocus>
                    Close Tab
                </Button>
            </DialogActions>
        </Dialog>
    )
}

CancelQuestionSetUpdateDialog.propTypes = {
    isOpen: PropTypes.bool.isRequired,
    isFromCreate: PropTypes.bool.isRequired,

    onHandleCancelApprove: PropTypes.func.isRequired,
    onHandleCancelDecline: PropTypes.func.isRequired
}

export default CancelQuestionSetUpdateDialog
