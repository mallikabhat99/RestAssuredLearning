/* globals expect, beforeEach, describe, it */
/*eslint "no-magic-numbers": ["error", {"ignore": [1, 2, 4000]}],*/
import React from 'react'
import { mount } from 'enzyme'
import { SnackbarSimple } from '@nwp/ui-components'
import { Notifications } from '.'

describe('Notifications Component', () => {

    let notificationsProps
    let notifications

    it('should be defined', () => {
        expect(Notifications).toBeDefined()
    })

    describe('Rendering with dismissed and displayed notifications', () => {
        beforeEach(() => {
            notificationsProps = {
                currentNotification: { id: 'currentId', error: true, message: 'test' },
                dismissedNotification: { id: 'dismissedId', error: true, message: 'test' },
                dismissNotification: jest.fn()
            }
            notifications = mount(<Notifications {...notificationsProps} />)
        })

        it('should render SnackbarSimple components', () => {
            const snackbar = notifications.find(SnackbarSimple)

            expect(snackbar.exists()).toBeTruthy()
            expect(snackbar).toHaveLength(2)
        })

        it('should have 4 seconds autoHideDuration property', () => {
            expect(notifications.find(SnackbarSimple).at(1).prop('autoHideDuration')).toEqual(4000)
        })

        it('should call dismissNotification on current snackbar onClose call', () => {
            notifications.find(SnackbarSimple).at(1).prop('onClose')()

            expect(notificationsProps.dismissNotification).toHaveBeenCalled()
        })

        it('should not call dismissNotification on current snackbar onClose call with clickaway reason', () => {
            notifications.find(SnackbarSimple).at(1).prop('onClose')(undefined, 'clickaway')

            expect(notificationsProps.dismissNotification).not.toHaveBeenCalled()
        })
    })

    describe('Rendering with dismissed only notification', () => {
        beforeEach(() => {
            notificationsProps = {
                dismissedNotification: { id: 'dismissedId', error: true, message: 'test' },
                dismissNotification: jest.fn()
            }
            notifications = mount(<Notifications {...notificationsProps} />)
        })

        it('should render SnackbarSimple components', () => {
            const snackbar = notifications.find(SnackbarSimple)

            expect(snackbar.exists()).toBeTruthy()
            expect(snackbar).toHaveLength(1)
        })
    })

    describe('Rendering with current only notification', () => {
        beforeEach(() => {
            notificationsProps = {
                currentNotification: { id: 'currentId', error: true, message: 'test' },
                dismissNotification: jest.fn()
            }
            notifications = mount(<Notifications {...notificationsProps} />)
        })

        it('should render SnackbarSimple components', () => {
            const snackbar = notifications.find(SnackbarSimple)

            expect(snackbar.exists()).toBeTruthy()
            expect(snackbar).toHaveLength(1)
        })
    })
})