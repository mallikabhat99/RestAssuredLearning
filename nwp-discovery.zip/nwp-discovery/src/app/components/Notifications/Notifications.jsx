import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import { SnackbarSimple } from '@nwp/ui-components'

class Notifications extends PureComponent {

    constructor (props) {
        super(props)

        this.handleCloseSnackbar = this.handleCloseSnackbar.bind(this)
    }

    handleCloseSnackbar (event, reason) {
        if (reason !== 'clickaway') {
            this.props.dismissNotification()
        }
    }

    render () {
        const {
            dismissedNotification: {
                id: dismissedId,
                error: dismissedError,
                message: dismissedMessage
            } = {},
            currentNotification: {
                id: currentId,
                error: currentError,
                message: currentMessage
            } = {}
        } = this.props

        return (
            <>
                {
                    dismissedId &&
                        <SnackbarSimple
                            key={dismissedId}
                            anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'center'
                            }}
                            error={dismissedError}
                            message={dismissedMessage}
                        />
                }
                {
                    currentId &&
                        <SnackbarSimple
                            key={currentId}
                            anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'center'
                            }}
                            autoHideDuration={4000}
                            open
                            onClose={this.handleCloseSnackbar}
                            error={currentError}
                            message={currentMessage}
                        />
                }
            </>
        )
    }
}

Notifications.propTypes = {
    currentNotification: PropTypes.shape({
        error: PropTypes.bool,
        message: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.arrayOf(PropTypes.string)
        ]).isRequired
    }),
    dismissedNotification: PropTypes.shape({
        error: PropTypes.bool,
        message: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.arrayOf(PropTypes.string)
        ]).isRequired
    }),
    dismissNotification: PropTypes.func.isRequired
}

export default Notifications