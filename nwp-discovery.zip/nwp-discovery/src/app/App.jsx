import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router-dom'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

import { Box, IntercomManager } from '@nwp/ui-components'
import {
    AssessmentDiscoveryContainer,
    AppRouteContainer,
    ConfigurationContainer,
    NotificationsContainer,
    QuestionSetsContainer,
    QuestionSetBuilderContainer
} from './containers'

class App extends Component {
    render () {
        const { intercomAppId } = this.props

        return (
            <Box display="flex" flexDirection="column" height="100vh">
                {intercomAppId && <IntercomManager intercomAppId={intercomAppId} />}
                <AppRouteContainer path="/discovery/:tab" component={AssessmentDiscoveryContainer} />
                <Box>
                    <Switch>
                        <Route path="/configuration/:entryPoint" component={ConfigurationContainer} />
                        <AppRouteContainer path="/discovery/:tab" component={QuestionSetsContainer} />
                        <AppRouteContainer path="/builder/:tab" component={QuestionSetBuilderContainer} />
                        <Route>
                            <Redirect to="/discovery/author" />
                        </Route>
                    </Switch>
                </Box>
                <NotificationsContainer />
            </Box>
        )
    }
}

App.propTypes = {
    intercomAppId: PropTypes.string
}

const mapStateToProps = ({
    configuration: {
        intercomAppId
    }
}) => ({
    intercomAppId
})

export default connect(mapStateToProps)(App)