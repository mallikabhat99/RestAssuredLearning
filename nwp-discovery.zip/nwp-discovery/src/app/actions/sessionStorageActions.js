import { createActions } from 'redux-actions'

const {
    save,
    update,
    remove
} = createActions(
    {
        SAVE: (key, value) => ({ key, value }),
        UPDATE: (key, value) => ({ key, value })
    },
    'REMOVE',
    {
        prefix: 'SESSION_STORAGE_ACTIONS'
    }
)

export default {
    save,
    update,
    remove
}