/* global expect, describe, beforeEach, it */

import reducer, * as Actions from './notifications'

describe('notifications Redux', () => {
    let state

    describe('Actions', () => {
        it('should provide necessary action creators', () => {
            expect(Actions.showNotification).toBeDefined()
            expect(Actions.dismissNotification).toBeDefined()
        })
    })

    describe('Reducer', () => {
        it('should provide a reducer', () => {
            expect(reducer).toBeDefined()
        })
    })

    describe('Action reducers', () => {
        beforeEach(() => {
            state = Actions.defaultState
        })

        describe('After showNotification action', () => {
            beforeEach(() => {
                state = reducer(state, Actions.showNotification({ test: 'test1' }))
            })

            it('should have currentNotification', () => {
                expect(state.currentNotification).toMatchObject({ test: 'test1' })
            })

            it('should have correct notifications', () => {
                expect(state.notifications).toHaveLength(0)
            })

            it('should have correct dismissedNotification', () => {
                expect(state).toHaveProperty('dismissedNotification', undefined)
            })

            describe('After second showNotification action', () => {
                beforeEach(() => {
                    state = reducer(state, Actions.showNotification({ test: 'test2' }))
                })

                it('should have currentNotification', () => {
                    expect(state.currentNotification).toMatchObject({ test: 'test1' })
                })

                it('should have correct notifications', () => {
                    expect(state.notifications).toHaveLength(1)
                })

                it('should have correct dismissedNotification', () => {
                    expect(state).toHaveProperty('dismissedNotification', undefined)
                })

                describe('After dismissNotification action', () => {
                    beforeEach(() => {
                        state = reducer(state, Actions.dismissNotification())
                    })

                    it('should have currentNotification', () => {
                        expect(state.currentNotification).toMatchObject({ test: 'test2' })
                    })

                    it('should have correct notifications', () => {
                        expect(state.notifications).toHaveLength(0)
                    })

                    it('should have correct dismissedNotification', () => {
                        expect(state.dismissedNotification).toMatchObject({ test: 'test1' })
                    })

                    describe('After second dismissNotification action', () => {
                        beforeEach(() => {
                            state = reducer(state, Actions.dismissNotification())
                        })

                        it('should have undefined currentNotification', () => {
                            expect(state).toHaveProperty('currentNotification', undefined)
                        })

                        it('should have correct notifications', () => {
                            expect(state.notifications).toHaveLength(0)
                        })

                        it('should have correct dismissedNotification', () => {
                            expect(state.dismissedNotification).toMatchObject({ test: 'test2' })
                        })
                    })
                })
            })
        })
    })
})