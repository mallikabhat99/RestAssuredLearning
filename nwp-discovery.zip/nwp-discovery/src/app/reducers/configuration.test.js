/* global expect, describe, it */

import reducer, * as Actions from './configuration'
import { RequestStatus } from '../entities'

describe('Configuration Redux', () => {
    let state

    it('should provide a reducer', () => {
        expect(typeof reducer).toEqual('function')
    })

    describe('Action reducers', () => {
        beforeEach(() => {
            state = Actions.defaultState
        })

        it('should update launchIdStatus with setLaunchIdStatus action', () => {
            expect(reducer(state, Actions.setLaunchIdStatus('test'))).
                toHaveProperty('launchIdStatus', 'test')
        })

        it('should update state with get configuration file action', () => {
            expect(reducer(state, Actions.getConfigurationFile())).
                toHaveProperty('configurationRequestStatus', RequestStatus.PROGRESS)
        })

        it('should update state with change configuration request status', () => {
            expect(reducer(state, Actions.setConfigurationRequestStatus('test-status'))).
                toHaveProperty('configurationRequestStatus', 'test-status')
        })

        describe('after setConfiguration action', () => {
            beforeEach(() => {
                state = reducer(state, Actions.setConfiguration({
                    serviceUrls: {
                        testService01Url: 'https://was.test.com/test01/path01',
                        testService02Url: 'https://was.test.com/test02/path02'
                    },
                    test: 'test',
                    intercomAppId: 'intercomAppId'
                }))
            })

            it('should have correct state', () => {
                expect(state).toMatchObject(
                    {
                        serviceUrls: {
                            testService01Url: 'https://was.test.com/test01/path01',
                            testService02Url: 'https://was.test.com/test02/path02'
                        },
                        intercomAppId: 'intercomAppId',
                        configurationRequestStatus: RequestStatus.OK
                    }
                )

                expect(state).not.toHaveProperty('test')
            })
        })

        it('should update launchContextRequestStatus with getLaunchContext action', () => {
            expect(reducer(state, Actions.getLaunchContext())).
                toHaveProperty('launchContextRequestStatus', RequestStatus.PROGRESS)
        })

        it('should update launchContextRequestStatus with setLaunchContextRequestStatus action', () => {
            expect(reducer(state, Actions.setLaunchContextRequestStatus('test-status'))).
                toHaveProperty('launchContextRequestStatus', 'test-status')
        })

        describe('after setLaunchContext action', () => {
            beforeEach(() => {
                state = reducer(state, Actions.setLaunchContext({
                    contextId: 'ctx00001',
                    productId: 'prod0001',
                    userId: 'usr0122'
                }))
            })

            it('should have correct state', () => {
                expect(state).toHaveProperty('contextId', 'ctx00001')
                expect(state).toHaveProperty('productId', 'prod0001')
                expect(state).toHaveProperty('userId', 'usr0122')

                expect(state).toHaveProperty('launchContextRequestStatus', RequestStatus.OK)
            })
        })
    })
})