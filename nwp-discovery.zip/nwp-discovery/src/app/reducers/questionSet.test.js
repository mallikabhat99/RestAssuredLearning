/* global expect, describe, it */
/*eslint "no-magic-numbers": ["error", {"ignore": [20, 0]}],*/

import reducer, * as Actions from './questionSet'
import { RequestStatus, AppParts } from '../entities'

describe('Question Sets Redux', () => {
    let state

    it('should provide a reducer', () => {
        expect(typeof reducer).toEqual('function')
    })

    describe('Action reducers', () => {
        beforeEach(() => {
            state = Actions.defaultState
        })

        it('should update state with setUserQuestionSetsRequestStatus action', () => {
            expect(
                reducer(
                    state,
                    Actions.setUserQuestionSetsRequestStatus(RequestStatus.OK)
                )
            ).toHaveProperty('userQuestionSetsRequestStatus', RequestStatus.OK)
        })

        it('should update state with setWileyQuestionSetsRequestStatus action', () => {
            expect(
                reducer(
                    state,
                    Actions.setWileyQuestionSetsRequestStatus(RequestStatus.INITIAL)
                )
            ).toHaveProperty('wileyQuestionSetsRequestStatus', RequestStatus.INITIAL)
        })

        it('should update state with getQuestionSets action', () => {
            expect(
                reducer(
                    state,
                    Actions.getQuestionSets(AppParts.MY_QUESTION_SET.name)
                )
            ).toHaveProperty('userQuestionSetsRequestStatus', RequestStatus.PROGRESS)
        })

        it('should update state with getQuestionSets action when status in initial', () => {
            expect(
                reducer(
                    state,
                    Actions.getQuestionSets(AppParts.MY_QUESTION_SET.value)
                )
            ).toHaveProperty('userQuestionSetsRequestStatus', RequestStatus.INITIAL)
        })

        it('should update state with getQuestionSets action when Wiley Question Set', () => {
            expect(
                reducer(
                    state,
                    Actions.getQuestionSets(AppParts.WILEY_QUESTION_SET.name)
                )
            ).toHaveProperty('wileyQuestionSetsRequestStatus', RequestStatus.PROGRESS)
        })

        it('should update state with getQuestionSets action when active tab is my question set', () => {
            const mockState = { ...state, merge: jest.fn() }
            mockState.userQuestionSetsRequestStatus = RequestStatus.OK
            expect(
                reducer(
                    mockState,
                    Actions.getQuestionSets(AppParts.WILEY_QUESTION_SET.name)
                )
            ).toHaveProperty('userQuestionSets', [])

        })

        it('should update state with getQuestionSets action when active tab is wiley question set', () => {
            const mockState = { ...state, merge: jest.fn() }
            mockState.wileyQuestionSetsRequestStatus = RequestStatus.OK
            expect(
                reducer(
                    mockState,
                    Actions.getQuestionSets(AppParts.MY_QUESTION_SET.name)
                )
            ).toHaveProperty('wileyQuestionSets', [])

        })

        it('should update state with attachQuestionSet action', () => {
            expect(
                reducer(
                    state,
                    Actions.attachQuestionSet()
                )
            ).toHaveProperty('setAttachQuestionSetStatus', RequestStatus.PROGRESS)
        })

        it('should update state with onTabChange action', () => {
            expect(
                reducer(
                    state,
                    Actions.onTabChange(AppParts.WILEY_QUESTION_SET.name)
                )
            ).toHaveProperty('selectedQuestionSetTab', AppParts.WILEY_QUESTION_SET.name)
        })

        it('should update state with deleteAssessment action', () => {
            expect(
                reducer(
                    state,
                    Actions.deleteAssessment()
                )
            ).toHaveProperty('deleteAssessmentRequestStatus', RequestStatus.PROGRESS)
        })

        it('should update state with setAttachQuestionSetStatus action', () => {
            expect(
                reducer(
                    state,
                    Actions.setAttachQuestionSetStatus(RequestStatus.INITIAL)
                )
            ).toHaveProperty('attachQuestionSetStatus', RequestStatus.INITIAL)
        })

        it('should update state with setSelectedMasterAssessmentId action', () => {
            expect(
                reducer(
                    state,
                    Actions.setSelectedMasterAssessmentId('masterAssessmentId')
                )
            ).toHaveProperty('selectedMasterAssessmentId', 'masterAssessmentId')
        })

        describe('should update state with setUserQuestionSets action', () => {
            beforeEach(() => {
                state = reducer(state, Actions.setUserQuestionSets({
                    items: []
                }))
            })

            it('should have correct state', () => {
                expect(state).toHaveProperty('userQuestionSets', [])
                expect(state).toHaveProperty('userQuestionSetsRequestStatus', RequestStatus.OK)
            })
        })

        describe('should update state with setWileyQuestionSets action', () => {
            beforeEach(() => {
                state = reducer(state, Actions.setWileyQuestionSets({
                    items: []
                }))
            })

            it('should have correct state', () => {
                expect(state).toHaveProperty('wileyQuestionSets', [])
                expect(state).toHaveProperty('wileyQuestionSetsRequestStatus', RequestStatus.OK)
            })
        })

        describe('should update state with setDeleteAssessmentRequestStatus action', () => {
            beforeEach(() => {
                state = reducer(state, Actions.setDeleteAssessmentRequestStatus({
                    deleteRequestStatus: RequestStatus.OK,
                    assessmentId: 'assessmetId'
                }))
            })

            it('should have correct state', () => {
                expect(state).toHaveProperty('deleteAssessmentRequestStatus', RequestStatus.OK)
                expect(reducer(state, Actions.setDeleteAssessmentRequestStatus({
                    deleteRequestStatus: RequestStatus.ERROR,
                    assessmentId: 'assessmetId'
                }))).not.toBeNull()
            })

            it('should set userQuestionSets when active tab is my question set and deleteRequestStatus is ok ', () => {
                const mockState = { ...state, merge: jest.fn() }
                mockState.selectedQuestionSetTab = AppParts.MY_QUESTION_SET.name
                mockState.userQuestionSets = [{
                    id: 'testId'
                }]
                expect(reducer(mockState, Actions.setDeleteAssessmentRequestStatus({ deleteRequestStatus: RequestStatus.OK, assessmentId: 'assessmentId' }))).not.toBeNull()
            })
        })
    })
})