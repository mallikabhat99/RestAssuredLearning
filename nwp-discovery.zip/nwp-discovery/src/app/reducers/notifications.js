import Immutable from 'seamless-immutable'
import { createActions, handleActions } from 'redux-actions'
import { utils } from '@nwp/ui-components'

export const defaultState = Immutable.from({
    currentNotification: undefined,
    notifications: [],
    dismissedNotification: undefined
})

export const { showNotification, dismissNotification } = createActions(
    {},
    'SHOW_NOTIFICATION',
    'DISMISS_NOTIFICATION'
)

const reducer = handleActions(
    {
        [showNotification]: (state, { payload: notification }) =>
            state.merge(state.currentNotification
                ? {
                    notifications: [...state.notifications, { ...notification, id: utils.idGenerator.generateSimpleId() }]
                }
                : {
                    currentNotification: { ...notification, id: utils.idGenerator.generateSimpleId() }
                }
            ),
        [dismissNotification]: state => {
            if (state.notifications.length) {
                const [currentNotification, ...notifications] = state.notifications

                return state.merge({
                    currentNotification,
                    notifications,
                    dismissedNotification: state.currentNotification
                })
            }
            return state.merge({
                currentNotification: undefined,
                dismissedNotification: state.currentNotification
            })
        }
    },
    defaultState
)

export default reducer