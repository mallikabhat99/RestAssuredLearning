import Immutable from 'seamless-immutable'
import { createActions, handleActions } from 'redux-actions'
import { RequestStatus } from '../entities'

export const defaultState = Immutable.from({
    launchIdStatus: RequestStatus.INITIAL,
    configurationRequestStatus: RequestStatus.INITIAL,
    launchContextRequestStatus: RequestStatus.INITIAL,
    intercomAppId: '',
    serviceUrls: {
        masterAssessmentsServiceUrl: '',
        assessmentDiscoveryUrl: ''
    },
    entryPoint: '',
    launchId: '',
    productId: '',
    courseId: '',
    contextId: '',
    userId: ''
})

export const {
    setConfigurationRequestStatus,
    setConfiguration,
    getConfigurationFile,
    setEntryPoint,
    setLaunchIdStatus,
    setLaunchContextRequestStatus,
    getLaunchContext,
    setLaunchContext
} = createActions(
    {},
    'SET_CONFIGURATION_REQUEST_STATUS',
    'SET_CONFIGURATION',
    'GET_CONFIGURATION_FILE',
    'SET_ENTRY_POINT',
    'SET_LAUNCH_ID_STATUS',
    'SET_LAUNCH_CONTEXT_REQUEST_STATUS',
    'GET_LAUNCH_CONTEXT',
    'SET_LAUNCH_CONTEXT'
)

const reducer = handleActions(
    {
        [setConfigurationRequestStatus]: (state, { payload: configurationRequestStatus }) =>
            state.merge({ configurationRequestStatus }),
        [setConfiguration]: (state, {
            payload: {
                serviceUrls,
                intercomAppId
            }
        }) =>
            state.merge({
                configurationRequestStatus: RequestStatus.OK,
                serviceUrls,
                intercomAppId
            }),
        [getConfigurationFile]: state =>
            state.merge({ configurationRequestStatus: RequestStatus.PROGRESS }),
        [setEntryPoint]: (state, { payload: { entryPoint, launchId } }) =>
            state.merge({ entryPoint, launchId, launchIdStatus: RequestStatus.OK }),
        [setLaunchIdStatus]: (state, { payload: launchIdStatus }) =>
            state.merge({ launchIdStatus }),

        [setLaunchContextRequestStatus]: (state, { payload: launchContextRequestStatus }) =>
            state.merge({ launchContextRequestStatus }),
        [setLaunchContext]: (state, { payload: { contextId, userId, productId } }) =>
            state.merge({ launchContextRequestStatus: RequestStatus.OK, contextId, userId, productId }),
        [getLaunchContext]: state =>
            state.merge({ launchContextRequestStatus: RequestStatus.PROGRESS })
    },
    defaultState
)

export default reducer