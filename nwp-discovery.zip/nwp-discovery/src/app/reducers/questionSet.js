import Immutable from 'seamless-immutable'
import { createActions, handleActions } from 'redux-actions'

import { RequestStatus, AppParts } from '../entities'

export const defaultState = Immutable.from({
    selectedQuestionSetTab: AppParts.MY_QUESTION_SET.name,
    userQuestionSetsRequestStatus: RequestStatus.INITIAL,
    wileyQuestionSetsRequestStatus: RequestStatus.INITIAL,
    deleteAssessmentRequestStatus: RequestStatus.INITIAL,
    wileyQuestionSetCount: 0,
    userQuestionSetCount: 0,
    userQuestionSets: [],
    wileyQuestionSets: [],
    attachQuestionSetStatus: RequestStatus.INITIAL,
    selectedMasterAssessmentId: ''
})

export const {
    // Actions with parameters
    onTabChange,
    getQuestionSets,
    attachQuestionSet,
    deleteAssessment,

    // Only actions
    setUserQuestionSets,
    setWileyQuestionSets,
    setUserQuestionSetsRequestStatus,
    setWileyQuestionSetsRequestStatus,
    setAttachQuestionSetStatus,
    setSelectedMasterAssessmentId,
    setDeleteAssessmentRequestStatus
} = createActions(
    {
        ON_TAB_CHANGE: (selectedTab) => ({ selectedTab }),
        GET_QUESTION_SETS: (selectedTab) => ({ selectedTab }),
        ATTACH_QUESTION_SET: (masterAssessmentId) => ({ masterAssessmentId }),
        DELETE_ASSESSMENT: (assessmentId) => ({ assessmentId })
    },
    'SET_USER_QUESTION_SETS',
    'SET_WILEY_QUESTION_SETS',
    'SET_USER_QUESTION_SETS_REQUEST_STATUS',
    'SET_WILEY_QUESTION_SETS_REQUEST_STATUS',
    'SET_ATTACH_QUESTION_SET_STATUS',
    'SET_SELECTED_MASTER_ASSESSMENT_ID',
    'SET_DELETE_ASSESSMENT_REQUEST_STATUS'
)

const reducer = handleActions(
    {
        [onTabChange]: (state, { payload: { selectedTab } }) => state.merge({ selectedQuestionSetTab: selectedTab }),
        [getQuestionSets]: (state, { payload: { selectedTab } }) =>
            state.merge({
                userQuestionSetsRequestStatus: selectedTab === AppParts.MY_QUESTION_SET.name ? RequestStatus.PROGRESS : state.userQuestionSetsRequestStatus,
                wileyQuestionSetsRequestStatus: selectedTab === AppParts.WILEY_QUESTION_SET.name
                    ? RequestStatus.PROGRESS : state.wileyQuestionSetsRequestStatus,
                userQuestionSets: selectedTab === AppParts.MY_QUESTION_SET.name || state.userQuestionSetsRequestStatus !== RequestStatus.OK
                    ? [] : state.userQuestionSets,
                wileyQuestionSets: selectedTab === AppParts.WILEY_QUESTION_SET.name || state.wileyQuestionSetsRequestStatus !== RequestStatus.OK
                    ? [] : state.wileyQuestionSets
            }),
        [attachQuestionSet]: state => state.merge({ setAttachQuestionSetStatus: RequestStatus.PROGRESS }),
        [deleteAssessment]: state => state.merge({ deleteAssessmentRequestStatus: RequestStatus.PROGRESS }),
        [setUserQuestionSets]: (state, { payload: { count, items } }) =>
            state.merge({
                userQuestionSets: items,
                userQuestionSetsRequestStatus: RequestStatus.OK
            }),
        [setWileyQuestionSets]: (state, { payload: { items } }) =>
            state.merge({
                wileyQuestionSets: items,
                wileyQuestionSetsRequestStatus: RequestStatus.OK
            }),
        [setUserQuestionSetsRequestStatus]: (state, { payload: userQuestionSetsRequestStatus }) => state.merge({ userQuestionSetsRequestStatus }),
        [setWileyQuestionSetsRequestStatus]: (state, { payload: wileyQuestionSetsRequestStatus }) => state.merge({ wileyQuestionSetsRequestStatus }),
        [setAttachQuestionSetStatus]: (state, { payload: attachQuestionSetStatus }) => state.merge({ attachQuestionSetStatus }),
        [setSelectedMasterAssessmentId]: (state, { payload: masterAssessmentId }) => state.merge({ selectedMasterAssessmentId: masterAssessmentId }),
        [setDeleteAssessmentRequestStatus]: (state, { payload: { deleteRequestStatus, assessmentId } }) =>
            state.merge({
                deleteAssessmentRequestStatus: deleteRequestStatus,
                userQuestionSets: state.selectedQuestionSetTab === AppParts.MY_QUESTION_SET.name && deleteRequestStatus === RequestStatus.OK
                    ? state.userQuestionSets.filter((item) => item.id !== assessmentId)
                    : state.userQuestionSets
            })
    },
    defaultState
)

export default reducer