import { combineReducers } from 'redux'
import { connectRouter } from 'connected-react-router'

import configuration, * as ActionsFromConfiguration from './configuration'
import questionSet, * as ActionsFromQuestionSet from './questionSet'
import notifications, * as ActionsNotifications from './notifications'

export const ConfigurationActions = ActionsFromConfiguration
export const QuestionSetActions = ActionsFromQuestionSet
export const NotificationsActions = ActionsNotifications

const createRootReducer = history => combineReducers({
    router: connectRouter(history),
    configuration,
    questionSet,
    notifications
})

export default createRootReducer