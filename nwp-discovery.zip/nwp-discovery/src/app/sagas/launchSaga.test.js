/* global expect, describe, it, beforeEach */

import { put, call, select } from 'redux-saga/effects'

import { loadLaunchContext, selectors } from './launchSaga'
import * as Actions from '../reducers/configuration'
import * as LaunchAPI from '../api/launchAPI'
import { RequestStatus } from '../entities'

// Helper function to step over the iterators
const stepper = fn => mock => fn.next(mock).value

describe('Launch Context sagas', () => {

    describe('should have proper selector object', () => {

        const selector = selectors.launchProps({
            configuration: {
                serviceUrls: {
                    launchServiceUrl: 'serviceUrl'
                },
                launchId: 'testLaunchId'
            }
        })

        expect(selector).toBeDefined()
    })

    describe('Loading Launch Context over a provided API', () => {
        let step

        beforeEach(() => {
            step = stepper(loadLaunchContext())
        })

        it('should select Launch Context props', () => {
            expect(step()).toEqual(select(selectors.launchProps))
        })

        describe('after select Launch Context props step', () => {
            beforeEach(() => {
                step()
            })

            it('should call an API', () => {
                expect(step({
                    serviceUrl: '',
                    launchId: ''
                })).toEqual(call(LaunchAPI.getLaunchContext, { serviceUrl: '', launchId: '' }))
            })

            describe('after API call step', () => {
                beforeEach(() => {
                    step({
                        serviceUrl: '',
                        launchId: ''
                    })
                })

                it('should put a necessary action once the data is loaded', () => {
                    const data = { test: 'test' }

                    expect(step({ data })).toEqual(put(Actions.setLaunchContext(data)))
                })

                it('should put a necessary action once the data load is failed', () => {
                    const err = 'testError'

                    expect(step({ err })).toEqual(put(Actions.setLaunchContextRequestStatus(RequestStatus.ERROR)))
                })
            })
        })
    })
})
