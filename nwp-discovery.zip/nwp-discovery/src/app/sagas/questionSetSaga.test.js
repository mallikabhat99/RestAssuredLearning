/* global expect, describe, it, beforeEach */

import { put, call, select, all } from 'redux-saga/effects'

import { getQuestionSets, selectors, attachQuestionSet, deleteAssessment } from './questionSetSaga'
import * as Actions from '../reducers/questionSet'
import * as questionSetAPI from '../api/questionSetAPI'

import { RequestStatus, AppParts } from '../entities'
import { showNotification } from '../reducers/notifications'

// Helper function to step over the iterators
const stepper = fn => mock => fn.next(mock).value

describe('Question Set sagas', () => {
    const assignMock = jest.fn()

    delete window.location
    window.location = { replace: assignMock }

    afterEach(() => {
        assignMock.mockClear()
    })

    describe('should have proper selector object', () => {

        const selector = selectors.questionSetProps({
            configuration: {
                serviceUrls: {
                    masterAssessmentsServiceUrl: 'serviceUrl',
                    assessmentDiscoveryUrl: 'assessmentDiscoveryUrl'
                },
                productId: 'testProductId',
                userId: 'testUserId',
                launchId: 'testlaunchId'
            }
        })

        expect(selector).toBeDefined()
    })

    describe('Loading Question Sets over a provided API', () => {
        let step

        beforeEach(() => {
            step = stepper(getQuestionSets({ payload: { selectedTab: AppParts.MY_QUESTION_SET.name } }))
        })

        it('should select Question Set props', () => {
            expect(step()).toEqual(select(selectors.questionSetProps))
        })

        describe('after select questionSetProps step', () => {
            beforeEach(() => {
                step()
            })

            it('should call an API', () => {

                expect(step({
                    serviceUrl: 'testUrl',
                    productId: 'testProductId',
                    userId: 'testUserId'
                })).toEqual(call(questionSetAPI.getQuestionSets, { serviceUrl: 'testUrl', productId: 'testProductId', userId: 'testUserId' }))
            })

            describe('after API call step', () => {
                beforeEach(() => {
                    step({
                        serviceUrl: 'testUrl',
                        productId: 'testProductId',
                        userId: 'testUserId'
                    })
                })

                it('should put a necessary action once the data is loaded', () => {
                    const data = { test: 'test' }

                    expect(step({ data })).toEqual(put(Actions.setUserQuestionSets(data)))
                })

                it('should put a necessary action once the data load is failed', () => {
                    const err = 'testError'

                    expect(step({ err })).toEqual(put(Actions.setUserQuestionSetsRequestStatus(RequestStatus.ERROR)))
                })
            })
        })
    })

    describe('Loading Question Sets over a provided API', () => {
        let step

        beforeEach(() => {
            step = stepper(getQuestionSets({ payload: { selectedTab: AppParts.WILEY_QUESTION_SET.name } }))
        })

        it('should select Question Set props', () => {
            expect(step()).toEqual(select(selectors.questionSetProps))
        })

        describe('after select questionSetProps step', () => {
            beforeEach(() => {
                step()
            })

            describe('after API call step', () => {
                beforeEach(() => {
                    step({
                        serviceUrl: 'testUrl',
                        productId: 'testProductId',
                        userId: 'testUserId'
                    })
                })

                it('should put a necessary action once the data is loaded when selected tab is WILEY_QUESTION_SET', () => {
                    const data = { test: 'test' }

                    expect(step({ data })).toEqual(put(Actions.setWileyQuestionSets(data)))
                })

                it('should put a necessary action once the data load is failed when selected tab is WILEY_QUESTION_SET', () => {
                    const err = 'testError'

                    expect(step({ err })).toEqual(put(Actions.setWileyQuestionSetsRequestStatus(RequestStatus.ERROR)))
                })
            })
        })
    })

    describe('Loading attachQuestionSet ', () => {

        it('should select Question Set props', () => {
            const gen = attachQuestionSet({ payload: { masterAssessmentId: 'masterAssessmentId' } })

            expect(gen.next().value).toEqual(select(selectors.questionSetProps))
            expect(gen.next(RequestStatus.OK).value).toEqual(put(Actions.setAttachQuestionSetStatus(RequestStatus.OK)))
            expect(gen.next().done).toBeTruthy()
        })
    })

    describe('Loading delete Assessment over a provided API', () => {
        let step

        beforeEach(() => {
            step = stepper(deleteAssessment({ payload: { assessmentId: 'assessmentId' } }))
        })

        it('should select Question Set props', () => {
            expect(step()).toEqual(select(selectors.questionSetProps))
        })

        describe('after select questionSetProps step', () => {

            beforeEach(() => {
                step()
            })

            describe('after API call step', () => {
                beforeEach(() => {
                    step({
                        serviceUrl: 'testUrl',
                        productId: 'testProductId',
                        userId: 'testUserId'
                    })
                })

                it('should put a necessary action once the data is loaded', () => {
                    const data = { test: 'test' }

                    expect(step({ data })).toEqual(all([
                        put(Actions.setDeleteAssessmentRequestStatus({
                            deleteRequestStatus: RequestStatus.OK,
                            assessmentId: 'assessmentId'
                        })),
                        put(showNotification({
                            error: false,
                            message: 'Question set deleted'
                        }))
                    ]))
                })

                it('should put a necessary action once the data is failed', () => {
                    const err = 'testError'

                    expect(step({ err })).toEqual(all([
                        put(Actions.setDeleteAssessmentRequestStatus({
                            deleteRequestStatus: RequestStatus.ERROR,
                            assessmentId: 'assessmentId'
                        })),
                        put(showNotification({
                            error: true,
                            message: 'Failed to delete question set'
                        }))
                    ]))
                })

            })
        })
    })
})