import { put, call, select, all } from 'redux-saga/effects'

import * as QuestionSetAPI from '../api/questionSetAPI'
import { RequestStatus, AppParts } from '../entities'
import {
    setUserQuestionSetsRequestStatus,
    setWileyQuestionSetsRequestStatus,
    setUserQuestionSets,
    setWileyQuestionSets,
    setAttachQuestionSetStatus,
    setDeleteAssessmentRequestStatus
} from '../reducers/questionSet'
import { showNotification } from '../reducers/notifications'

export const selectors = {
    questionSetProps: ({
        configuration: {
            serviceUrls: {
                masterAssessmentsServiceUrl: serviceUrl,
                assessmentDiscoveryUrl
            },
            productId,
            userId,
            launchId
        }
    }) =>
        ({
            serviceUrl,
            assessmentDiscoveryUrl,
            productId,
            userId,
            launchId
        })
}

export function * getQuestionSets ({ payload: { selectedTab } }) {
    const getQuestionSetProps = yield select(selectors.questionSetProps)
    getQuestionSetProps.userId = (selectedTab === AppParts.MY_QUESTION_SET.name) ? getQuestionSetProps.userId : 'Wiley'

    const { err, data } = yield call(QuestionSetAPI.getQuestionSets, getQuestionSetProps)
    if (err) {
        if (selectedTab === AppParts.MY_QUESTION_SET.name) {
            yield put(setUserQuestionSetsRequestStatus(RequestStatus.ERROR))
        } else {
            yield put(setWileyQuestionSetsRequestStatus(RequestStatus.ERROR))
        }
    } else {
        if (selectedTab === AppParts.MY_QUESTION_SET.name) {
            yield put(setUserQuestionSets(data))
        } else {
            yield put(setWileyQuestionSets(data))
        }
    }
}

export function * attachQuestionSet ({ payload: { masterAssessmentId } }) {
    const getQuestionSetProps = yield select(selectors.questionSetProps)
    const assessmentDiscoveryUrl = getQuestionSetProps.assessmentDiscoveryUrl

    window.location.replace(
        `${assessmentDiscoveryUrl}/select-assessment/${masterAssessmentId}`
    )
    yield put(setAttachQuestionSetStatus(RequestStatus.OK))
}

export function * deleteAssessment ({ payload: { assessmentId } }) {
    const { serviceUrl } = yield select(selectors.questionSetProps)

    const { err } = yield call(QuestionSetAPI.deleteMasterAssessment, {serviceUrl, assessmentId })

    if (err) {
        yield all([
            put(setDeleteAssessmentRequestStatus({deleteRequestStatus: RequestStatus.ERROR, assessmentId: assessmentId})),
            put(showNotification({
                error: true,
                message: 'Failed to delete question set'
            }))
        ])
    } else {
        yield all([
            put(setDeleteAssessmentRequestStatus({deleteRequestStatus: RequestStatus.OK, assessmentId: assessmentId})),
            put(showNotification({
                error: false,
                message: 'Question set deleted'
            }))
        ])
    }
}