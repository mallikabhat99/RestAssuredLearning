import { takeLatest, takeEvery, all } from 'redux-saga/effects'

import { ConfigurationActions, QuestionSetActions } from '../reducers'

import { loadConfigFile } from './configurationSaga'
import { loadLaunchContext } from './launchSaga'
import { getQuestionSets, attachQuestionSet, deleteAssessment } from './questionSetSaga'

export default function * root () {
    yield all([
        takeLatest(ConfigurationActions.getConfigurationFile.toString(), loadConfigFile),
        takeLatest(ConfigurationActions.getLaunchContext.toString(), loadLaunchContext),
        takeEvery(QuestionSetActions.getQuestionSets.toString(), getQuestionSets),
        takeLatest(QuestionSetActions.attachQuestionSet.toString(), attachQuestionSet),
        takeLatest(QuestionSetActions.deleteAssessment.toString(), deleteAssessment)
    ])
}