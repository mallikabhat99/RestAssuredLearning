import { put, call, select } from 'redux-saga/effects'

import { getLaunchContext } from '../api/launchAPI'
import { RequestStatus } from '../entities'
import {
    setLaunchContextRequestStatus,
    setLaunchContext
} from '../reducers/configuration'

export const selectors = {
    launchProps: ({
        configuration: {
            serviceUrls: {
                launchServiceUrl: serviceUrl
            },
            launchId
        }
    }) =>
        ({
            serviceUrl,
            launchId
        })
}

export function * loadLaunchContext () {
    const getLaunchProps = yield select(selectors.launchProps)

    const { err, data } = yield call(getLaunchContext, getLaunchProps)

    if (err) {
        yield put(setLaunchContextRequestStatus(RequestStatus.ERROR))
    } else {
        yield put(setLaunchContext(data))
    }

}