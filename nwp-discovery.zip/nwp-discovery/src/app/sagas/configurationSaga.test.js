/* global expect, describe, it, beforeEach */

import { put, call } from 'redux-saga/effects'

import { loadConfigFile } from './configurationSaga'
import * as Actions from '../reducers/configuration'
import * as ConfigurationAPI from '../api/configurationAPI'
import { ConfigurationUtilities, RequestStatus } from '../entities'

// Helper function to step over the iterators
const stepper = fn => mock => fn.next(mock).value

describe('Configuration sagas', () => {
    describe('Loading Configuration File over a provided API', () => {
        let step

        beforeEach(() => {
            step = stepper(loadConfigFile())
        })

        it('should call an API', () => {
            expect(step()).toEqual(call(ConfigurationAPI.getConfigFile))
        })

        describe('after API call step', () => {
            const data = {
                services: {
                    was: {
                        baseUrl: 'https://was.test.com',
                        paths: {
                            testService01Url: '/test01/path01',
                            testService02Url: '/test02/path02'
                        },
                        intercomAppId: 'testId'
                    },
                    wpng: {
                        baseUrl: 'https://wpng.test.com',
                        paths: {
                            testService03Url: '/test03/path03',
                            testService04Url: '/test04/path04'
                        }
                    }
                },
                intercomAppId: 'ulnb38da'
            }

            beforeEach(() => {
                step()
            })

            it('should put a necessary action once the data load is failed', () => {
                const err = 'testError'
                expect(step({ err })).toEqual(put(Actions.setConfigurationRequestStatus(RequestStatus.ERROR)))
            })

            it('should call transformServiceUrls utility method', () => {
                expect(step({ data })).toEqual(call(ConfigurationUtilities.transformServiceUrls, data.services))
            })

            describe('configuration Redux update', () => {
                beforeEach(() => {
                    step({ data })
                })

                it('should put a necessary action once the data is loaded and refined', () => {
                    const serviceUrls = {
                        testService01Url: 'https://was.test.com/test01/path01',
                        testService02Url: 'https://was.test.com/test02/path02'
                    }
                    expect(step(serviceUrls)).toEqual(put(Actions.setConfiguration({ intercomAppId: 'ulnb38da', serviceUrls })))
                })
            })
        })
    })
})
