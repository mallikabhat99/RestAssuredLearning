import { put, call } from 'redux-saga/effects'

import * as configurationAPI from '../api/configurationAPI'
import { ConfigurationUtilities, RequestStatus } from '../entities'
import {
    setConfiguration,
    setConfigurationRequestStatus
} from '../reducers/configuration'

export function * loadConfigFile () {
    const { data, err } = yield call(configurationAPI.getConfigFile)

    if (err) {
        yield put(setConfigurationRequestStatus(RequestStatus.ERROR))
    } else {
        const { services, ...configuration } = data
        const serviceUrls = yield call(ConfigurationUtilities.transformServiceUrls, data.services)

        yield put(setConfiguration({ ...configuration, serviceUrls }))
    }
}