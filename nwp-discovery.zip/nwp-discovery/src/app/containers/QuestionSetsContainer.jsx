import { connect } from 'react-redux'
import { withRouter } from 'react-router'
import { push } from 'connected-react-router'

import { QuestionSet } from '../components'
import { QuestionSetActions } from '../reducers'

const mapStateToProps = ({
    configuration: {
        launchId
    },
    questionSet: {
        userQuestionSets,
        wileyQuestionSets,
        userQuestionSetsRequestStatus,
        wileyQuestionSetsRequestStatus
    }
}) => ({
    launchId,
    userQuestionSets,
    wileyQuestionSets,
    userQuestionSetsRequestStatus,
    wileyQuestionSetsRequestStatus
})

const mapDispatchToProps = dispatch => ({
    getQuestionSets: (selectedTab) => dispatch(QuestionSetActions.getQuestionSets(selectedTab)),
    attachQuestionSet: (masterAssessmentId) => dispatch(QuestionSetActions.attachQuestionSet(masterAssessmentId)),
    setSelectedMasterAssessmentId: (masterAssessmentId) => dispatch(QuestionSetActions.setSelectedMasterAssessmentId(masterAssessmentId)),
    onPush: (url) => dispatch(push(url)),
    deleteAssessment: (assessmentId) => dispatch(QuestionSetActions.deleteAssessment(assessmentId))
})

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(QuestionSet))