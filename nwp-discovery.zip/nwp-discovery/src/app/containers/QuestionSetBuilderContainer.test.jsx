import React from 'react'
import { mount } from 'enzyme'
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { QuestionSetBuilder } from '../components'
import { LocalStorageActions } from '../actions'
import { QuestionSetActions } from '../reducers'
import { QuestionSetBuilderContainer } from '.'
import { MemoryRouter } from 'react-router'
import { push } from 'connected-react-router'

describe('QuestionSetBuilderContainer Container', () => {
    window.open = jest.fn()

    const mockState = {
        configuration: {
            launchId: 'testId'
        },
        questionSet: {
            selectedMasterAssessmentId: ''
        }
    }

    it('should be defined', () => {
        expect(QuestionSetBuilder).toBeDefined()
    })

    describe('Rendering', () => {
        let wrapper, questionSetBuilderContainer, mockStore

        beforeEach(() => {
            mockStore = configureStore([])(mockState)
            mockStore.dispatch = jest.fn()
            wrapper = mount(
                <MemoryRouter>
                    <Provider store={mockStore}>
                        <QuestionSetBuilderContainer {...mockState} />
                    </Provider>
                </MemoryRouter>
            )
            questionSetBuilderContainer = wrapper.find(QuestionSetBuilderContainer)
        })

        it('should render QuestionSetBuilder Component', () => {
            expect(questionSetBuilderContainer.find(QuestionSetBuilder).exists()).toBeTruthy()
        })

        it('should dispatch attachQuestionSet action', () => {
            questionSetBuilderContainer.find(QuestionSetBuilder).prop('attachQuestionSet')('masterAssessmentId')
            expect(mockStore.dispatch).toHaveBeenCalledWith(QuestionSetActions.attachQuestionSet('masterAssessmentId'))
        })

        it('should dispatch onPush action', () => {
            questionSetBuilderContainer.find(QuestionSetBuilder).prop('onPush')('url')

            expect(mockStore.dispatch).toHaveBeenCalled()
            expect(mockStore.dispatch).toHaveBeenCalledWith(push('url'))
        })

        it('should dispatch removeFromLocalStorage action', () => {
            questionSetBuilderContainer.find(QuestionSetBuilder).prop('removeFromLocalStorage')('key')
            expect(mockStore.dispatch).toHaveBeenCalledWith(LocalStorageActions.remove('key'))
        })

        it('should dispatch setSelectedMasterAssessmentId action', () => {
            questionSetBuilderContainer.find(QuestionSetBuilder).prop('setSelectedMasterAssessmentId')('masterAssessmentId')
            expect(mockStore.dispatch).toHaveBeenCalledWith(QuestionSetActions.setSelectedMasterAssessmentId('masterAssessmentId'))
        })

    })
})