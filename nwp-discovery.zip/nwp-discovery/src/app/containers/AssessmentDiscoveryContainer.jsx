import { connect } from 'react-redux'
import { withRouter } from 'react-router'
import { push } from 'connected-react-router'

import { AssessmentDiscovery } from '../components'
import { QuestionSetActions } from '../reducers'

const mapStateToProps = ({
    questionSet: {
        userQuestionSets,
        wileyQuestionSets,
        userQuestionSetsRequestStatus,
        wileyQuestionSetsRequestStatus
    }
}) => ({
    userQuestionSets,
    wileyQuestionSets,
    userQuestionSetsRequestStatus,
    wileyQuestionSetsRequestStatus
})

const mapDispatchToProps = dispatch => ({
    getQuestionSets: (selectedTab) => dispatch(QuestionSetActions.getQuestionSets(selectedTab)),
    onPush: (url) => dispatch(push(url)),
    onTabChange: (selectedTab) => dispatch(QuestionSetActions.onTabChange(selectedTab))
})

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(AssessmentDiscovery))