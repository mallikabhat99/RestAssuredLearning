/* globals jest, expect, beforeEach, describe, it */

import React from 'react'
import { mount } from 'enzyme'
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { MemoryRouter } from 'react-router-dom'

import { AppRoute } from '../components'
import { AppRouteContainer, AssessmentDetailsContainer } from '.'
import { RequestStatus } from '../entities'

describe('App Route Container', () => {
    const mockState = {
        assessment: {
            title: ''
        },
        configuration: {
            launchContextRequestStatus: RequestStatus.INITIAL,
            entryPoint: ''
        },
        router: {
            location: {
                pathname: '/details'
            }
        }
    }

    it('should be defined', () => {
        expect(AppRouteContainer).toBeDefined()
    })

    describe('Rendering', () => {
        let wrapper, appRouteContainer, mockStore

        beforeEach(() => {
            mockStore = configureStore([])(mockState)
            mockStore.dispatch = jest.fn()
            wrapper = mount(
                <Provider store={mockStore}>
                    <MemoryRouter initialEntries={['/one', { pathname: '/details' }]}>
                        <AppRouteContainer path="/details" component={AssessmentDetailsContainer} />
                    </MemoryRouter>
                </Provider>
            )
            appRouteContainer = wrapper.find(AppRouteContainer)
        })

        it('should render AssessmentDetails Component', () => {
            expect(appRouteContainer.find(AppRoute).exists()).toBeTruthy()
        })
    })

    describe('Rendering with RequestStatus.OK status', () => {
        let wrapper, appRouteContainer, mockStore

        beforeEach(() => {
            mockStore = configureStore([])({
                ...mockState,
                configuration: {
                    ...mockState.configuration,
                    launchContextRequestStatus: RequestStatus.OK
                }
            })
            mockStore.dispatch = jest.fn()
            wrapper = mount(
                <Provider store={mockStore}>
                    <MemoryRouter initialEntries={['/one', { pathname: '/details' }]}>
                        <AppRouteContainer path="/details" component={AssessmentDetailsContainer} />
                    </MemoryRouter>
                </Provider>
            )
            appRouteContainer = wrapper.find(AppRouteContainer)
        })

        it('should have isReady property as true Component', () => {
            expect(appRouteContainer.find(AppRoute).prop('isReady')).toBeTruthy()
        })
    })
})