/* globals jest, expect, beforeEach, describe, it */
/* eslint no-magic-numbers: 0 */

import React from 'react'
import { mount } from 'enzyme'
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { MemoryRouter } from 'react-router-dom'
import { Configuration } from '../components'
import { ConfigurationContainer } from '.'
import { RequestStatus } from '../entities'
import { getConfigurationFile, getLaunchContext, setEntryPoint } from '../reducers/configuration'

describe('Configuration Container', () => {

    const mockState = {
        assessment: {
            title: '',
            items: []
        },
        configuration: {
            assessment: {
                title: '',
                items: []
            },
            launchIdStatus: RequestStatus.INITIAL,
            configurationRequestStatus: RequestStatus.INITIAL,
            launchContextRequestStatus: RequestStatus.INITIAL,
            serviceUrls: {
                productServiceUrl: ''
            },
            entryPoint: '',
            launchId: '',
            productId: '',
            courseId: ''
        }
    }

    it('should be defined', () => {
        expect(ConfigurationContainer).toBeDefined()
    })

    describe('Rendering', () => {
        let wrapper, configurationContainer, mockStore

        beforeEach(() => {
            mockStore = configureStore([])(mockState)
            mockStore.dispatch = jest.fn()
            wrapper = mount(
                <Provider store={mockStore}>
                    <MemoryRouter>
                        <ConfigurationContainer path="/configuration/details" component={Configuration} />
                    </MemoryRouter>
                </Provider>
            )
            configurationContainer = wrapper.find(ConfigurationContainer)
        })

        it('should render Configuration Component', () => {
            expect(configurationContainer.find(Configuration).exists()).toBeTruthy()
        })

        describe('Actions Dispatching', () => {
            it('should dispatch getConfigurationFile action', () => {
                configurationContainer.find(Configuration).prop('getConfigurationFile')()
                expect(mockStore.dispatch).toHaveBeenCalledWith(getConfigurationFile())
            })

            it('should dispatch getLaunchContext action', () => {
                configurationContainer.find(Configuration).prop('getLaunchContext')()
                expect(mockStore.dispatch).toHaveBeenCalledWith(getLaunchContext())
            })

            it('should dispatch getLaunchContext action', () => {
                configurationContainer.find(Configuration).prop('setEntryPoint')('entryPoint', 'launchId')
                expect(mockStore.dispatch).toHaveBeenCalledWith(setEntryPoint({ entryPoint: 'entryPoint', launchId: 'launchId' }))
            })

        })
    })
})