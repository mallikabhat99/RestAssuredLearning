import { connect } from 'react-redux'
import { withRouter } from 'react-router'

import { Configuration } from '../components'
import { getConfigurationFile, getLaunchContext, setEntryPoint, setLaunchIdStatus } from '../reducers/configuration'

const mapStateToProps = ({ configuration: { configurationRequestStatus, launchIdStatus, launchContextRequestStatus, entryPoint } }) =>
    ({
        configurationRequestStatus, launchIdStatus, launchContextRequestStatus, entryPoint
    })

const mapDispatchToProps = dispatch => ({
    getConfigurationFile: () => dispatch(getConfigurationFile()),
    getLaunchContext: () => dispatch(getLaunchContext()),
    setEntryPoint: (entryPoint, launchId) => dispatch(setEntryPoint({ entryPoint, launchId })),
    setLaunchIdStatus: launchIdStatus => dispatch(setLaunchIdStatus(launchIdStatus))
})

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(Configuration))