import { connect } from 'react-redux'

import { Notifications } from '../components'
import { NotificationsActions } from '../reducers'

const mapStateToProps = ({
    notifications: { currentNotification, dismissedNotification }
}) => ({
    currentNotification,
    dismissedNotification
})

const mapDispatchToProps = dispatch => ({
    dismissNotification: () => dispatch(NotificationsActions.dismissNotification())
})

export default connect(mapStateToProps, mapDispatchToProps)(Notifications)
