import { connect } from 'react-redux'
import { withRouter } from 'react-router'
import { push } from 'connected-react-router'

import { QuestionSetBuilder } from '../components'
import { LocalStorageActions } from '../actions'
import { QuestionSetActions } from '../reducers'

const mapStateToProps = ({
    configuration: {
        launchId
    },
    questionSet: {
        selectedMasterAssessmentId
    }
}) => ({
    launchId,
    selectedMasterAssessmentId
})

const mapDispatchToProps = dispatch => ({
    attachQuestionSet: (masterAssessmentId) => dispatch(QuestionSetActions.attachQuestionSet(masterAssessmentId)),
    onPush: (url) => dispatch(push(url)),
    setToLocalStorage: (key, value) => dispatch(LocalStorageActions.save(key, value)),
    removeFromLocalStorage: (key) => dispatch(LocalStorageActions.remove(key)),
    setSelectedMasterAssessmentId: (masterAssessmentId) => dispatch(QuestionSetActions.setSelectedMasterAssessmentId(masterAssessmentId))
})

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(QuestionSetBuilder))