import React from 'react'
import { mount } from 'enzyme'
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { MemoryRouter } from 'react-router'
import { push } from 'connected-react-router'
import QuestionSetsContainer from './QuestionSetsContainer'
import { QuestionSet } from '../components'
import { QuestionSetActions } from '../reducers'
import { AppParts } from '../entities'

describe('QuestionSetsContainer Container', () => {

    const mockState = {
        match: { params: { tab: AppParts.MY_QUESTION_SET.name } },
        configuration: {
            launchId: 'testId'
        },
        questionSet: {
            userQuestionSets: [],
            wileyQuestionSets: [],
            userQuestionSetsRequestStatus: '',
            wileyQuestionSetsRequestStatus: ''
        }
    }

    it('should be defined', () => {
        expect(QuestionSetsContainer).toBeDefined()
    })

    describe('Rendering', () => {
        let wrapper, questionSetsContainer, mockStore

        beforeEach(() => {
            mockStore = configureStore([])(mockState)
            mockStore.dispatch = jest.fn()
            wrapper = mount(
                <MemoryRouter>
                    <Provider store={mockStore}>
                        <QuestionSetsContainer {...mockState} />
                    </Provider>
                </MemoryRouter>
            )
            questionSetsContainer = wrapper.find(QuestionSetsContainer)
        })

        it('should render QuestionSet Component', () => {
            expect(questionSetsContainer.find(QuestionSet).exists()).toBeTruthy()
        })

        it('should dispatch getQuestionSets action', () => {
            questionSetsContainer.find(QuestionSet).prop('getQuestionSets')('selectedTab')
            expect(mockStore.dispatch).toHaveBeenCalledWith(QuestionSetActions.getQuestionSets('selectedTab'))
        })

        it('should dispatch attachQuestionSet action', () => {
            questionSetsContainer.find(QuestionSet).prop('attachQuestionSet')('masterAssessmentId')
            expect(mockStore.dispatch).toHaveBeenCalledWith(QuestionSetActions.attachQuestionSet('masterAssessmentId'))
        })

        it('should dispatch setSelectedMasterAssessmentId action', () => {
            questionSetsContainer.find(QuestionSet).prop('setSelectedMasterAssessmentId')('masterAssessmentId')
            expect(mockStore.dispatch).toHaveBeenCalledWith(QuestionSetActions.setSelectedMasterAssessmentId('masterAssessmentId'))
        })

        it('should dispatch onPush action', () => {
            questionSetsContainer.find(QuestionSet).prop('onPush')('url')
            expect(mockStore.dispatch).toHaveBeenCalledWith(push('url'))
        })

        it('should dispatch deleteAssessment action', () => {
            questionSetsContainer.find(QuestionSet).prop('deleteAssessment')('assessmentId')
            expect(mockStore.dispatch).toHaveBeenCalledWith(QuestionSetActions.deleteAssessment('assessmentId'))
        })

    })
})