import { connect } from 'react-redux'
import { withRouter } from 'react-router'

import { AppRoute } from '../components'
import { RequestStatus } from '../entities'

const getAppReadyness = launchContextRequestStatus => {
    let isReady = false
    if (launchContextRequestStatus === RequestStatus.OK) {
        isReady = true
    }
    return isReady
}

const mapStateToProps = ({ configuration: { launchContextRequestStatus } }) =>
    ({ isReady: getAppReadyness(launchContextRequestStatus) })

export default connect(mapStateToProps)(withRouter(AppRoute))