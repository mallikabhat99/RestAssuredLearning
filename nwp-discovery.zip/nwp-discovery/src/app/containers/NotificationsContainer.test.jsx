/* globals jest, expect, beforeEach, describe, it */
/* eslint no-magic-numbers: 0 */

import React from 'react'
import { mount } from 'enzyme'
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { Notifications } from '../components'
import { NotificationsActions } from '../reducers'
import { NotificationsContainer } from '.'

describe('NotificationsContainer Container', () => {
    const mockState = {
        notifications: {
            notifications: [],
            currentNotification: { message: 'test' }
        }
    }

    it('should be defined', () => {
        expect(NotificationsContainer).toBeDefined()
    })

    describe('Rendering', () => {
        let wrapper, contentContainer, mockStore

        beforeEach(() => {
            mockStore = configureStore([])(mockState)
            mockStore.dispatch = jest.fn()
            wrapper = mount(
                <Provider store={mockStore}>
                    <NotificationsContainer />
                </Provider>
            )
            contentContainer = wrapper.find(NotificationsContainer)
        })

        it('should render Notifications Component', () => {
            expect(contentContainer.find(Notifications).exists()).toBeTruthy()
        })

        it('should dispatch dismissNotification NotificationActions action on Notifications dismissNotification call', () => {
            contentContainer.find(Notifications).prop('dismissNotification')()

            expect(mockStore.dispatch).toHaveBeenCalled()
            expect(mockStore.dispatch).toHaveBeenCalledWith(NotificationsActions.dismissNotification())
        })
    })
})