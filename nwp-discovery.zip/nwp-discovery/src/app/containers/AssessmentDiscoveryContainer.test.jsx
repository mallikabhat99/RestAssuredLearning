/* globals jest, expect, beforeEach, describe, it */
/* eslint no-magic-numbers: 0 */

import React from 'react'
import { mount } from 'enzyme'
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { MemoryRouter } from 'react-router-dom'
import { AssessmentDiscovery } from '../components'
import { AssessmentDiscoveryContainer } from '.'
import { QuestionSetActions } from '../reducers'
import { AppParts, RequestStatus } from '../entities'
import { push } from 'connected-react-router'

describe('AssessmentDiscovery Container', () => {

    const mockState = {
        onPush: jest.fn(),
        questionSet: {
            userQuestionSets: [],
            wileyQuestionSets: [],
            userQuestionSetsRequestStatus: RequestStatus.OK,
            wileyQuestionSetsRequestStatus: RequestStatus.OK
        },
        getQuestionSets: jest.fn(),
        onTabChange: jest.fn(),
        router: {
            location: {
                pathname: '/discovery/author'
            }
        }
    }

    it('should be defined', () => {
        expect(AssessmentDiscoveryContainer).toBeDefined()
    })

    describe('Rendering', () => {
        let wrapper, assessmentDiscoveryContainer, mockStore

        beforeEach(() => {
            mockStore = configureStore([])(mockState)
            mockStore.dispatch = jest.fn()
            wrapper = mount(
                <Provider store={mockStore}>
                    <MemoryRouter initialEntries={['/one', { pathname: '/discovery/author' }]}>
                        <AssessmentDiscoveryContainer path="/discovery/author" component={AssessmentDiscovery} />
                    </MemoryRouter>
                </Provider>
            )
            assessmentDiscoveryContainer = wrapper.find(AssessmentDiscoveryContainer)
        })

        it('should render AssessmentDiscovery Component', () => {
            expect(assessmentDiscoveryContainer.find(AssessmentDiscovery).exists()).toBeTruthy()
        })

        describe('Actions Dispatching', () => {
            it('should dispatch getQuestionSets action', () => {
                assessmentDiscoveryContainer.find(AssessmentDiscovery).prop('getQuestionSets')(AppParts.MY_QUESTION_SET.name)

                expect(mockStore.dispatch).toHaveBeenCalled()
                expect(mockStore.dispatch).toHaveBeenCalledWith(QuestionSetActions.getQuestionSets(AppParts.MY_QUESTION_SET.name))
            })

            it('should dispatch onPush action', () => {
                assessmentDiscoveryContainer.find(AssessmentDiscovery).prop('onPush')('url')

                expect(mockStore.dispatch).toHaveBeenCalled()
                expect(mockStore.dispatch).toHaveBeenCalledWith(push('url'))
            })

            it('should dispatch onTabChange action', () => {
                assessmentDiscoveryContainer.find(AssessmentDiscovery).prop('onTabChange')(AppParts.MY_QUESTION_SET.name)
                expect(mockStore.dispatch).toHaveBeenCalledWith(QuestionSetActions.onTabChange(AppParts.MY_QUESTION_SET.name))
            })
        })
    })
})