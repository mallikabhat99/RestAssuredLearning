/* global expect, describe, it, beforeEach */
/*eslint "no-magic-numbers": ["error", {"ignore": [200]}],*/

import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

import { getConfigFile } from './configurationAPI'
import { AppProperties } from '../entities'

describe('Configuration File API', () => {
    let mock = null

    beforeEach(() => {
        mock = new MockAdapter(axios)
    })

    it('correct getConfigFile api call', done => {
        mock.onGet(AppProperties.CONFIG_FILE_URL).reply(200, [{ test: 'test' }])

        getConfigFile().then(({ data }) => {
            expect(data).toEqual([{ test: 'test' }])
            done()
        })
    })

    it('incorrect getConfigFile api call', done => {
        mock.onGet('/was/ui/v2/was-config.json').networkError()

        getConfigFile().then(errorResponse => {
            expect(errorResponse).toHaveProperty('err')
            done()
        })
    })
})