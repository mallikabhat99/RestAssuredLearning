import axios from 'axios'

const api = url => axios.create({
    baseURL: url,
    withCredentials: true
})

export const getQuestionSets = ({ serviceUrl, productId, userId }) =>
    api(serviceUrl).get('', {
        params: {
            product: productId,
            author: userId,
            sortby: 'title',
            order: 'asc'
        }
    })
        .then(response => response)
        .catch(err => ({ err }))

export const deleteMasterAssessment = ({ serviceUrl, assessmentId }) =>
    api(serviceUrl).delete(`/${assessmentId}`)
        .then(response => response)
        .catch(err => ({ err }))