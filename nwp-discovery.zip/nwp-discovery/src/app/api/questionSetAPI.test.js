/* global expect, describe, it, beforeEach */
/*eslint "no-magic-numbers": ["error", {"ignore": [200]}],*/

import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

import { getQuestionSets, deleteMasterAssessment } from './questionSetAPI'

describe('Question set API', () => {
    let mock = null

    beforeEach(() => {
        mock = new MockAdapter(axios)
    })

    it('correct getQuestionSets api call', done => {
        mock.onGet('').reply(200, [{ test: 'test' }])

        getQuestionSets({ serviceUrl: '/api/v1/master/assessments', productId: 'testProductId', userId: 'testUserId' }).then(({ data }) => {
            expect(data).toEqual([{ test: 'test' }])
            done()
        })
    })

    it('incorrect getQuestionSets api call', done => {
        mock.onGet('').networkError()

        getQuestionSets({ serviceUrl: '/api/v1/master/assessments', productId: 'testProductId', userId: 'testUserId' }).then(errorResponse => {
            expect(errorResponse).toHaveProperty('err')
            done()
        })
    })

    it('correct deleteMasterAssessment api call', done => {
        mock.onDelete('/assessmentId').reply(200, [{ test: 'test' }])

        deleteMasterAssessment({ serviceUrl: '/api/v1/master/assessments', assessmentId: 'assessmentId' }).then(({ data }) => {
            expect(data).toEqual([{ test: 'test' }])
            done()
        })
    })

    it('incorrect deleteMasterAssessment api call', done => {
        mock.onDelete('/assessmentId').networkError()

        deleteMasterAssessment({ serviceUrl: '/api/v1/master/assessments', assessmentId: 'assessmentId' }).then(errorResponse => {
            expect(errorResponse).toHaveProperty('err')
            done()
        })
    })
})