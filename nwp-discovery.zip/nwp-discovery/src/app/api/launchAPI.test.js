/* global expect, describe, it, beforeEach */
/*eslint "no-magic-numbers": ["error", {"ignore": [200]}],*/

import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

import { getLaunchContext } from './launchAPI'

describe('Configuration File API', () => {
    let mock = null

    beforeEach(() => {
        mock = new MockAdapter(axios)
    })

    it('correct getLaunchContext api call', done => {
        mock.onGet('/launchServiceUrl/v1/launches/dev00001').reply(200, [{ test: 'test' }])

        getLaunchContext({ serviceUrl: '/launchServiceUrl/v1/launches', launchId: 'dev00001' }).then(({ data }) => {
            expect(data).toEqual([{ test: 'test' }])
            done()
        })
    })

    it('incorrect getConfigFile api call', done => {
        mock.onGet('/launchServiceUrl/v1/launches/dev00001').networkError()

        getLaunchContext({ serviceUrl: '/launchServiceUrl/v1/launches', launchId: 'dev00001' }).then(errorResponse => {
            expect(errorResponse).toHaveProperty('err')
            done()
        })
    })
})