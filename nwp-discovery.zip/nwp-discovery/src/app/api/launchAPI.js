import axios from 'axios'

const api = url => axios.create({
    baseURL: url,
    withCredentials: true
})

export const getLaunchContext = ({ serviceUrl, launchId }) =>
    api(serviceUrl).get(`/${launchId}`)
        .then(response => response)
        .catch(err => ({ err }))