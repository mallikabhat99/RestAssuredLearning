import axios from 'axios'

import { AppProperties } from '../entities'

const api = () => axios.create({
    withCredentials: true
})

export const getConfigFile = () =>
    api().get(AppProperties.CONFIG_FILE_URL)
        .then(response => response)
        .catch(err => ({ err }))