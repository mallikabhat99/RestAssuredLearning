export default {
    profileName: 'Homework',
    itemPolicies: null,
    accommodationRefId: null
}