/* global expect, describe, it */
import ConfigurationUtilities from './ConfigurationUtilities'

describe('ConfigurationUtilities library', () => {

    describe('transformServiceUrls method', () => {

        let configurationFileData = {}

        beforeEach(() => {
            configurationFileData = {
                was: {
                    baseUrl: 'https://was.test.com',
                    paths: {
                        testService01Url: '/test01/path01',
                        testService02Url: '/test02/path02'
                    }
                },
                wpng: {
                    baseUrl: 'https://wpng.test.com',
                    paths: {
                        testService03Url: '/test03/path03',
                        testService04Url: '/test04/path04'
                    }
                }
            }
        })

        it('should properly sort usersList', () => {
            const result = {
                testService01Url: 'https://was.test.com/test01/path01',
                testService02Url: 'https://was.test.com/test02/path02',
                testService03Url: 'https://wpng.test.com/test03/path03',
                testService04Url: 'https://wpng.test.com/test04/path04'
            }

            expect(ConfigurationUtilities.transformServiceUrls(configurationFileData)).toEqual(result)
        })
    })
})