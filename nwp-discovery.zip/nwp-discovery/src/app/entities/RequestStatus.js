export default {
    INITIAL: 'initial',
    OK: 'ok',
    PROGRESS: 'progress',
    ERROR: 'error'
}