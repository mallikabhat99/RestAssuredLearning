const appParts = {
    MY_QUESTION_SET: {
        name: 'author',
        value: 'MY QUESTION SETS'
    },
    WILEY_QUESTION_SET: {
        name: 'wiley',
        value: 'WILEY QUESTION SETS'
    }
}

export const appPartsArray = Object.values(appParts)

export default appParts