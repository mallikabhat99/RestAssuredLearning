export default {
    APP_NAME: 'assessment-discovery',
    CONFIG_FILE_URL: '/was/ui/v2/config/was-config.json'
}