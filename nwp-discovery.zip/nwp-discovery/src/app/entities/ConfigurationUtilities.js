// Helper function to transform was_config.json properties
const transformServiceUrls = configObj =>
    Object.values(configObj).reduce((urlsAccumulator, { baseUrl, paths }) => ({
        ...urlsAccumulator,
        ...Object.keys(paths).reduce((singleEnvironmentUrlsAccumulator, serviceUrlName) => ({
            ...singleEnvironmentUrlsAccumulator,
            [serviceUrlName]: `${baseUrl}${paths[serviceUrlName]}`
        }), {})
    }), {})

export default {
    transformServiceUrls
}