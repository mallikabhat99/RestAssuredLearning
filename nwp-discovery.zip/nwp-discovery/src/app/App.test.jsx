import React from 'react'
import { mount } from 'enzyme'
import { MemoryRouter } from 'react-router-dom'
import { Provider } from 'react-redux'
import store from './storage'
import App from './App'

describe('Configuration component', () => {
    let appComponent

    beforeEach(() => {

        appComponent = mount(
            <Provider store={store}>
                <MemoryRouter>
                    <App />
                </MemoryRouter>
            </Provider>
        )
    })

    it('should be defined', () => {
        expect(App).toBeDefined()
    })

    it('should render AppComponent', () => {
        expect(appComponent.exists()).toBeTruthy()
    })
})