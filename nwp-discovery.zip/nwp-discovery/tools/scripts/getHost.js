const os = require('os')

const ifaces = os.networkInterfaces()

module.exports = () => Object.values(ifaces).reduce((addressAccumulator, addressArray) =>
    addressArray.reduce((internalAddressAccumulator, { family, internal, address }) =>
        family === 'IPv4' && !internal ? address : internalAddressAccumulator, addressAccumulator
    ), 'localhost'
)
